<aside class="sidebar">
                    <!-- Categories Widget -->
                    <div class="widget widget-categories">
                        <h3 class="widget-title">Product Categories</h3>
                        <ul class="category-list">
                            <li class="category-item active">
                                <a href="#">
                                    <span class="category-name">All Products</span>
                                    <span class="category-count">24</span>
                                </a>
                            </li>
                            <li class="category-item">
                                <a href="#">
                                    <span class="category-name">Passenger Vehicle</span>
                                    <span class="category-count">8</span>
                                </a>
                            </li>
                            <li class="category-item">
                                <a href="#">
                                    <span class="category-name">Commercial Vehicle</span>
                                    <span class="category-count">6</span>
                                </a>
                            </li>
                            <li class="category-item">
                                <a href="#">
                                    <span class="category-name">Electric &amp; Hybrid</span>
                                    <span class="category-count">4</span>
                                </a>
                            </li>
                            <li class="category-item">
                                <a href="#">
                                    <span class="category-name">Off-Highway</span>
                                    <span class="category-count">4</span>
                                </a>
                            </li>
                            <li class="category-item">
                                <a href="#">
                                    <span class="category-name">Custom Solutions</span>
                                    <span class="category-count">2</span>
                                </a>
                            </li>
                        </ul>
                    </div>

                    <!-- Contact Widget -->
                    <div class="widget widget-contact">
                        <h3 class="widget-title">Need Assistance?</h3>
                        <div class="contact-info">
                            <div class="contact-item">
                                <div class="contact-icon">
                                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M3 8L10.89 13.26C11.5396 13.6778 12.4604 13.6778 13.11 13.26L21 8M5 19H19C20.1046 19 21 18.1046 21 17V7C21 5.89543 20.1046 5 19 5H5C3.89543 5 3 5.89543 3 7V17C3 18.1046 3.89543 19 5 19Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path>
                                    </svg>
                                </div>
                                <div class="contact-details">
                                    <span class="contact-label">Email</span>
                                    <a href="mailto:sales@precisionhub.com" class="contact-value">sales@precisionhub.com</a>
                                </div>
                            </div>
                            <div class="contact-item">
                                <div class="contact-icon">
                                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M3 5C3 3.89543 3.89543 3 5 3H8.27924C8.70967 3 9.09181 3.27543 9.22792 3.68377L10.7257 8.17721C10.8831 8.64932 10.6694 9.16531 10.2243 9.38787L7.96701 10.5165C9.06925 12.9612 11.0388 14.9308 13.4835 16.033L14.6121 13.7757C14.8347 13.3306 15.3507 13.1169 15.8228 13.2743L20.3162 14.7721C20.7246 14.9082 21 15.2903 21 15.7208V19C21 20.1046 20.1046 21 19 21H18C9.71573 21 3 14.2843 3 6V5Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path>
                                    </svg>
                                </div>
                                <div class="contact-details">
                                    <span class="contact-label">Phone</span>
                                    <a href="tel:+15551234567" class="contact-value">+1 (555) 123-4567</a>
                                </div>
                            </div>
                            <div class="contact-item">
                                <div class="contact-icon">
                                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M12 2C8.13401 2 5 5.13401 5 9C5 14.25 12 22 12 22C12 22 19 14.25 19 9C19 5.13401 15.866 2 12 2Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path>
                                        <path d="M12 11C13.1046 11 14 10.1046 14 9C14 7.89543 13.1046 7 12 7C10.8954 7 10 7.89543 10 9C10 10.1046 10.8954 11 12 11Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path>
                                    </svg>
                                </div>
                                <div class="contact-details">
                                    <span class="contact-label">Location</span>
                                    <span class="contact-value">Detroit, Michigan, USA</span>
                                </div>
                            </div>
                        </div>
                        <a href="index.html#contact" class="widget-cta">Request Quote</a>
                    </div>
                </aside>