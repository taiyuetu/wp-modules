<?php
/**
 * The template for displaying all single posts.
 *
 * @package WP_Starter
 */

get_header();
tqb_page_banner();
?>
<section class="product-detail-section">
<!--  --><div class="container">
            <div class="product-detail-layout">
            	
                <!-- Product Images -->
                <div class="product-images">
                    <div class="product-main-image">
                        <?php
$gallery_images = get_post_meta(get_the_ID(), 'product_gallery', true);
$gallery_images = explode(',', $gallery_images); ?>
                    <!-- based on the fields to select the badget -->
                        <span class="product-badge-detail">Best Seller</span>
                        <div class="main-image-placeholder" style="opacity: 1;">
                            <?php echo wp_get_attachment_image($gallery_images[0], 'full'); ?>
                        </div>
                    </div>
                    <div class="product-thumbnails">
                        <?php

if (!empty($gallery_images)) {
    foreach ($gallery_images as $key => $image) {
        $image_url = wp_get_attachment_image_url($image, 'full'); ?>
        <div class="thumbnail <?php echo $key == 0 ? 'active' : ''; ?>">
                            <img src="<?php echo $image_url; ?>" alt="<?php echo get_the_title(); ?>">
                        </div>

  <?php
    }
}
?>
                    </div>
                </div>
                <!-- Product Info -->
                <div class="product-info-detail">
                    <h2 class="product-title-detail"><?php the_title(); ?></h2>
                    <p class="product-model">Model: <?php echo get_post_meta(get_the_ID(), 'partnumber', true); ?></p>
                    <div class="product-rating">
                        <?php product_review_starts(); ?>
                        <span class="rating-count"></span>
                    </div>
                    
                    <div class="product-excerpt">
                        <p><?php echo mb_strimwidth(strip_tags(get_the_content()), 0, 150); ?></p>
                    </div>
                    
                    <div class="product-price">
                        <span class="price-label"><a href="<?php echo home_url('/contact'); ?>">Contact for Pricing</a></span>
                    </div>
                    
                    <div class="product-meta-info">
                        <div class="meta-item">
                            <span class="meta-label">OEM Number:</span>
                            <span class="meta-value"><?php echo get_post_meta(get_the_ID(), 'oem_num', true); ?></span>
                        </div>
                        <div class="meta-item">
                            <span class="meta-label">Category:</span>
                            <span class="meta-value"><?php echo get_the_term_list(get_the_ID(), 'product_category', '', ', ', ''); ?></span>
                        </div>
                        <div class="meta-item">
                            <span class="meta-label">Availability:</span>
                            <span class="meta-value in-stock">In Stock</span>
                        </div>
                    </div>
                    
                    <div class="product-actions">
                        <a href="<?php echo home_url('/contact'); ?>" class="btn btn-primary btn-large">Request Quote</a>
                        <a href="#downloads" class="btn btn-secondary btn-large">Download Technical Sheet</a>
                    </div>
                    
                    <div class="product-features-quick">
                        <h3>Key Features</h3>
                        <ul>
                            <?php
// 这里还是直接从系统字段里进行设置修改一次就好不是每个产品都有不同的features的
$key_features = get_post_meta(get_the_ID(), 'key_features', true);

if (is_array($key_features)) {
    foreach ($key_features as $key_feature) { ?>
                                <li><?php echo $key_feature; ?></li>
                            <?php
    }
}
else {
    echo '<li>No key features found.</li>';
}?>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="product-tabs-section">
        <div class="container">
            <div class="tabs-nav">
                <button class="tab-btn active" data-tab="description">Description</button>
                <button class="tab-btn" data-tab="specifications">Applications table</button>
                <button class="tab-btn" data-tab="downloads">Downloads</button>
            </div>

            <div class="tabs-content">
                <div class="tab-pane active" id="description">
                    <h2>Product Description</h2>
                    <?php the_content(); ?>
                </div>

                <div class="tab-pane" id="specifications">
                    <h2>Applications table</h2>
                    <div class="specs-grid">
                        <div class="spec-group">
                            <h3>Dimensional Data</h3>
                            <?php
echo do_shortcode('[wtm_table id="1"]');
?>
                        </div>
                        
                       
                            
                        
                    </div>
                </div>

                <div class="tab-pane" id="downloads">
                    <h2>Technical Documentation 这里放图纸电子版画册之类</h2>
                    <div class="downloads-list">
<?php



//这个是获取到product文章的drawing字段，返回的是一个数组，数组里面是download文章的id
$downloads = get_post_meta(get_the_ID(), 'drawing', true);

if (is_array($downloads)) {
    //循环每一篇download文章    
    foreach ($downloads as $download) {
        // $download是文章类型，需要获取到download文章下面的upload file的信息
        //第一步先获取到download文章下面的upload file的信息
        //因为字段设置的是输出id，所以$download_id就是download文章下面的upload file的id
        $download_id = get_post_meta($download, 'download_file', true);
        //这里就相当于获取到了attachment_id
        var_dump($download_id);

        $file_path = get_attached_file($download_id);
        $file_size = filesize($file_path);
        $file_size_formatted = size_format($file_size);
        $file_url = wp_get_attachment_url($download_id);

?>

<div class="download-item">
    <div class="download-icon">
        <svg width="48" height="48" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M12 16H36M12 24H36M12 32H28" stroke="#1D4E89" stroke-width="2" stroke-linecap="round"></path>
            <rect x="8" y="8" width="32" height="32" rx="2" stroke="#1D4E89" stroke-width="2"></rect>
        </svg>
    </div>
    <div class="download-info">
        <h4><?php echo get_the_title($download_id); ?></h4>
        <p><?php echo get_post_field('post_content', $download_id); ?></p>
        <span class="download-meta">PDF • <?php echo $file_size_formatted; ?></span>
    </div>
    <a href="<?php echo $file_url; ?>" class="download-btn" target="_blank" download=<?php echo get_the_title($download_id); ?>>
        <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M10 3V13M10 13L6 9M10 13L14 9M3 17H17" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path>
        </svg>
        Download
    </a>
</div>


<?php
    }
}
else {
    echo '<li>No downloads found.</li>';
}

?>
                        
                        

                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="related-products">
        <div class="container">
            <h2 class="section-title">Related Products</h2>
            <div class="related-grid">
                <div class="related-product-card">
                    <div class="related-product-image">
                        <svg width="80" height="80" viewBox="0 0 80 80" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <circle cx="40" cy="40" r="35" stroke="#1D4E89" stroke-width="3"></circle>
                            <circle cx="40" cy="40" r="25" stroke="#1D4E89" stroke-width="2"></circle>
                            <circle cx="40" cy="40" r="8" fill="#1D4E89"></circle>
                        </svg>
                    </div>
                    <h3 class="related-product-name">Heavy Duty HD-Series</h3>
                    <p class="related-product-code">WHB-HD-5080</p>
                    <a href="#" class="related-product-link">View Details </a>
                </div>
                
                <div class="related-product-card">
                    <div class="related-product-image">
                        <svg width="80" height="80" viewBox="0 0 80 80" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <circle cx="40" cy="40" r="35" stroke="#1D4E89" stroke-width="2"></circle>
                            <circle cx="40" cy="40" r="25" stroke="#1D4E89" stroke-width="3"></circle>
                            <circle cx="40" cy="40" r="8" fill="#1D4E89"></circle>
                            <path d="M40 10 L40 20 M40 60 L40 70 M10 40 L20 40 M60 40 L70 40" stroke="#1D4E89" stroke-width="2"></path>
                        </svg>
                    </div>
                    <h3 class="related-product-name">EV-Optimized E-Drive Hub</h3>
                    <p class="related-product-code">WHB-EV-3060</p>
                    <a href="#" class="related-product-link">View Details ��</a>
                </div>
                
                <div class="related-product-card">
                    <div class="related-product-image">
                        <svg width="80" height="80" viewBox="0 0 80 80" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <circle cx="40" cy="40" r="35" stroke="#1D4E89" stroke-width="2"></circle>
                            <circle cx="40" cy="40" r="25" stroke="#1D4E89" stroke-width="2"></circle>
                            <circle cx="40" cy="40" r="15" stroke="#1D4E89" stroke-width="2"></circle>
                            <circle cx="40" cy="40" r="8" fill="#1D4E89"></circle>
                        </svg>
                    </div>
                    <h3 class="related-product-name">Precision Tapered Roller</h3>
                    <p class="related-product-code">WHB-TR-3555</p>
                    <a href="#" class="related-product-link">View Details ��</a>
                </div>
                
                <div class="related-product-card">
                    <div class="related-product-image">
                        <svg width="80" height="80" viewBox="0 0 80 80" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <circle cx="40" cy="40" r="35" stroke="#1D4E89" stroke-width="2"></circle>
                            <circle cx="40" cy="40" r="25" stroke="#1D4E89" stroke-width="2"></circle>
                            <circle cx="40" cy="40" r="8" fill="#1D4E89"></circle>
                            <path d="M25 25 L55 55 M25 55 L55 25" stroke="#1D4E89" stroke-width="2"></path>
                        </svg>
                    </div>
                    <h3 class="related-product-name">High-Speed Performance</h3>
                    <p class="related-product-code">WHB-HS-3050</p>
                    <a href="#" class="related-product-link">View Details ��</a>
                </div>
            </div>
        </div>
    </section>


<?php

get_footer();
