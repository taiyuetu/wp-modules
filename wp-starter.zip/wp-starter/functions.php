<?php
/**
 * WP Starter Theme functions and definitions.
 *
 * @package WP_Starter
 */

if (!defined('ABSPATH')) {
	exit;
}

define('WP_STARTER_VERSION', '1.0.0');

require get_template_directory() . '/inc/setup.php';
require get_template_directory() . '/inc/enqueue.php';
require get_template_directory() . '/inc/template-tags.php';

// The common-scripts.php enqueued all assets indiscriminately, causing style conflicts.
// require_once get_template_directory() . '/framework/functions/common-scripts.php';

require_once get_template_directory() . '/framework/vendor/wp-rapid-fields.php';
require_once get_template_directory() . '/framework/admin/wrf-init.php';

require_once get_template_directory() . '/framework/widgets.php';
require_once get_template_directory() . '/framework/functions/theme-functions.php';

require_once get_template_directory() . '/framework/admin/ws-nav-walker.php';

require_once get_template_directory() . '/framework/admin/custom-sliders.php';

require_once get_template_directory() . '/framework/admin/ws-posttypes.php';

//theme blocks 
require_once get_template_directory() . '/themeblocks/themeblocks.php';

// =========================================================================
require_once get_template_directory() . '/framework/admin/clean-ups.php';


require_once get_template_directory() . '/framework/admin/products-enhancement.php';


//user avatar
require_once get_template_directory() . '/framework/admin/user-avatar.php';


//image_collections 
require_once get_template_directory() . '/framework/admin/image-collections.php';

//templates tags
require_once get_template_directory() . '/framework/functions/template-tags.php';


// contact form
require_once get_template_directory() . '/framework/admin/ws-custom-form.php';

//widgets
require_once get_template_directory() . '/framework/widgets.php';