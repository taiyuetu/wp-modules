 <!-- Footer -->
    <footer class="footer">
        <div class="container">
            <div class="footer-content">
                <?php 
                if (is_active_sidebar('footer-sidebar')) {
                    dynamic_sidebar( 'footer-sidebar' );
                } ?>
                
       
            </div>
            <div class="footer-bottom">
                <p>&copy; 2026 PrecisionHub Manufacturing. All rights reserved.</p>
                <div class="footer-legal">
                    <a href="#">Privacy Policy</a>
                    <a href="#">Terms of Service</a>
                </div>
            </div>
        </div>
    </footer>


    <!-- Floating Widget -->
    <div class="floating-widget">
        <!-- Go to Top Button -->
        <button id="scrollTopBtn" class="widget-btn scroll-top-btn" aria-label="Scroll to top">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M12 19V5M12 5L5 12M12 5L19 12" stroke="currentColor" stroke-width="2" stroke-linecap="round"
                    stroke-linejoin="round" />
            </svg>
        </button>

        <!-- Email Button -->
        <div class="widget-item">
            <button id="emailBtn" class="widget-btn email-btn" aria-label="Email Us">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path
                        d="M4 4H20C21.1 4 22 4.9 22 6V18C22 19.1 21.1 20 20 20H4C2.9 20 2 19.1 2 18V6C2 4.9 2.9 4 4 4Z"
                        stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                    <path d="M22 6L12 13L2 6" stroke="currentColor" stroke-width="2" stroke-linecap="round"
                        stroke-linejoin="round" />
                </svg>
            </button>
            <div id="emailPopup" class="widget-popup email-popup">
                <div class="popup-header">
                    <h3>Contact Us</h3>
                    <button class="close-popup" aria-label="Close">&times;</button>
                </div>
                <div class="popup-content">
                    <p>Send us an email at:</p>
                    <a href="mailto:info@precisionhub.com" class="popup-link">info@precisionhub.com</a>
                </div>
            </div>
        </div>

        <!-- WhatsApp Button -->
        <div class="widget-item">
            <button id="whatsappBtn" class="widget-btn whatsapp-btn" aria-label="Chat on WhatsApp">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path
                        d="M21 11.5C21.0039 12.8199 20.6812 14.1272 20.063 15.3C19.4447 16.4728 18.5516 17.4714 17.4682 18.2016C16.3848 18.9318 15.1472 19.37 13.8717 19.4752C12.5962 19.5804 11.3251 19.349 10.18 18.8L3 21L5.2 13.8C4.65104 12.6549 4.41963 11.3838 4.52483 10.1083C4.63002 8.83281 5.06822 7.59521 5.79843 6.51179C6.52864 5.42837 7.52719 4.53527 8.70001 3.91703C9.87283 3.29879 11.1801 2.97607 12.5 2.98003H13C15.0843 3.09701 17.0425 4.01509 18.4433 5.53457C19.8441 7.05405 20.6124 9.09249 20.58 11.18L21 11.5Z"
                        stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                </svg>
            </button>
            <div id="whatsappPopup" class="widget-popup whatsapp-popup">
                <div class="popup-header">
                    <h3>WhatsApp</h3>
                    <button class="close-popup" aria-label="Close">&times;</button>
                </div>
                <div class="popup-content">
                    <p>Scan to chat with us:</p>
                    <div class="qr-placeholder">
                        <svg width="150" height="150" viewBox="0 0 150 150" fill="none"
                            xmlns="http://www.w3.org/2000/svg">
                            <rect width="150" height="150" fill="#f0f0f0" />
                            <rect x="20" y="20" width="40" height="40" stroke="#333" stroke-width="4" />
                            <rect x="90" y="20" width="40" height="40" stroke="#333" stroke-width="4" />
                            <rect x="20" y="90" width="40" height="40" stroke="#333" stroke-width="4" />
                            <rect x="35" y="35" width="10" height="10" fill="#333" />
                            <rect x="105" y="35" width="10" height="10" fill="#333" />
                            <rect x="35" y="105" width="10" height="10" fill="#333" />
                            <rect x="80" y="80" width="50" height="50" fill="#333" opacity="0.2" />
                        </svg>
                    </div>
                </div>
            </div>
        </div>
    </div>


</body>
 <?php wp_footer(); ?>

</html>