<?php
/**
 * The sidebar containing the main widget area.
 *
 * @package WP_Starter
 */

if ( ! is_active_sidebar( 'sidebar-1' ) ) {
	return;
}
?>

<aside id="secondary" class="widget-area container">
	<?php dynamic_sidebar( 'sidebar-1' ); ?>
</aside>

