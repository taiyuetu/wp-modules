<div class="product-card">
                    <div class="product-image">
                        <!-- <div class="product-badge">Best Seller</div> -->
                        <div class="product-image-placeholder">
                            <?php the_post_thumbnail('medium'); ?>
                        </div>
                    </div>
                    <div class="product-info">
                        <h3 class="product-name"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
                        <p class="product-code">Model: <?php echo get_post_meta( get_the_ID(), 'partnumber', true ); ?></p>
                        <p class="product-description"><?php echo mb_strimwidth(strip_tags(get_the_content()), 0, 100) ?></p>

                        <div class="product-specs">
                            <?php

                            $tags = get_the_tags(  );
                            if ($tags) {

                                foreach ($tags as $tag) {  ?>
                               <span class="spec-tag"><a href="<?php echo get_tag_link( $tag ); ?>"><?php echo $tag->name; ?></a></span> 

                        <?php    }
                                
                            }
                            

                             ?>
                        </div>
                        <a href="<?php the_permalink(  ); ?>" class="product-link">View Details →</a>
                    </div>
                </div>