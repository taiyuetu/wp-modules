<?php
/**
 * The main template file.
 *
 * @package WP_Starter
 */

get_header();

?>

<?php
$args = array(
    'post_type' => 'csp_slider',
    'posts_per_page' => 1,
    'orderby' => 'date',
    'order' => 'DESC'
);
$sliders = get_posts($args);
$slider_slides = [];
if (!empty($sliders)) {
    $slider_slides = get_post_meta($sliders[0]->ID, '_csp_slides', true);
}
?>

<!-- Hero Slider -->
    <section class="hero-slider" id="heroSlider">
        <div class="slider-track">
            <?php
if (!empty($slider_slides)):
    foreach ($slider_slides as $index => $slide):
        $active_class = ($index === 0) ? ' active' : '';
        $link = !empty($slide['link']) ? esc_url($slide['link']) : '#';
        $image_url = !empty($slide['image_url']) ? esc_url($slide['image_url']) : '';
?>
                    <a href="<?php echo $link; ?>" class="slide<?php echo $active_class; ?>">
                        <div class="slide-background"
                            style="background-image: url('<?php echo $image_url; ?>');">
                        </div>
                    </a>
                <?php
    endforeach;
else: ?>
                <a href="#contact" class="slide active">
                    <div class="slide-background"
                        style="background-image: url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTAwJSIgaGVpZ2h0PSIxMDAlIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxyZWN0IHdpZHRoPSIxMDAlIiBoZWlnaHQ9IjEwMCUiIGZpbGw9IiMxRDRFODkiLz48L3N2Zz4=');">
                    </div>
                </a>
            <?php
endif; ?>
        </div>
        <div class="slider-controls">
            <button class="slider-arrow slider-arrow-prev" aria-label="Previous slide">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M15 18L9 12L15 6" stroke="currentColor" stroke-width="2" stroke-linecap="round"
                        stroke-linejoin="round" />
                </svg>
            </button>
            <button class="slider-arrow slider-arrow-next" aria-label="Next slide">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M9 18L15 12L9 6" stroke="currentColor" stroke-width="2" stroke-linecap="round"
                        stroke-linejoin="round" />
                </svg>
            </button>
        </div>
        <div class="slider-dots">
            <?php
if (!empty($slider_slides)):
    foreach ($slider_slides as $index => $slide):
        $active_class = ($index === 0) ? ' active' : '';
?>
                    <button class="slider-dot<?php echo $active_class; ?>" data-slide="<?php echo $index; ?>" aria-label="Go to slide <?php echo $index + 1; ?>"></button>
                <?php
    endforeach;
else: ?>
                <button class="slider-dot active" data-slide="0" aria-label="Go to slide 1"></button>
            <?php
endif; ?>
        </div>
    </section>

    

    <!-- Search Bar -->
    <div class="search-bar" id="searchBar">
        <div class="container search-container">
            <?php get_search_form(  ); ?>
            <button class="search-close" id="searchClose" aria-label="Close search">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M18 6L6 18M6 6L18 18" stroke="currentColor" stroke-width="2" stroke-linecap="round" />
                </svg>
            </button>
        </div>
    </div>

    <!-- Hero Section -->
    <?php

$blocks = parse_blocks(get_the_content());
foreach ($blocks as $block):
    if (isset($block['blockName']) && $block['blockName'] === 'tqb/hero'):
        echo render_block($block);
        break;
    endif;
endforeach;

?>

    <!-- Trust Section -->
    <?php
foreach ($blocks as $block):
    if (isset($block['blockName']) && $block['blockName'] === 'custom/trust-section'):
        echo render_block($block);
        break;
    endif;
endforeach;


?>
    

    <!-- Featured Products Section -->
    <section class="featured-products" id="products">
        <div class="container">
            <div class="section-header">
                <p class="section-label">Product Portfolio</p>
                <h2 class="section-title">Featured Wheel Hub Bearings</h2>
                <p class="section-description">
                    Precision-engineered bearing solutions for diverse applications. Each product designed for optimal
                    performance, durability, and reliability.
                </p>
            </div>
            <div class="products-grid">
                <?php
                    $featured_products = new WP_Query(array(
                        'post_type' => 'product',
                        'posts_per_page' => 8,
                        'meta_key' => 'featured',
                        'meta_value' => '1',
                        'orderby' => 'menu_order',
                        'order' => 'ASC',
                        'post_status' => 'publish',
                    ));
                    ?>
                <?php while ($featured_products->have_posts()):
    $featured_products->the_post(); 
    get_template_part( 'template-parts/content', 'product' );
    
endwhile; ?>
                <?php wp_reset_postdata(); ?>
            </div>
        </div>
    </section>

    <!-- Features Section -->
    <?php 
    foreach ($blocks as $block):
    if (isset($block['blockName']) && $block['blockName'] === 'tqb/features-section'):
        echo render_block($block);
        break;
    endif;
endforeach;

     ?>

 

    <!-- Why Choose Us Section -->
    
      <?php 
    foreach ($blocks as $block):
    if (isset($block['blockName']) && $block['blockName'] === 'custom/why-choose-us'):
        echo render_block($block);
        break;
    endif;
endforeach;

     ?>
    <!-- Deep Value Section -->
    <?php 
    foreach ($blocks as $block):
    if (isset($block['blockName']) && $block['blockName'] === 'custom/value-section'):
        echo render_block($block);
        break;
    endif;
endforeach;

     ?>

    <!-- Applications Section -->
     <?php 
    foreach ($blocks as $block):
    if (isset($block['blockName']) && $block['blockName'] === 'custom/applications'):
        echo render_block($block);
        break;
    endif;
endforeach;

     ?>
    

    <!-- Image Showcase Carousel -->
    <section class="showcase-carousel">
        <div class="container">
            <div class="section-header">
                <p class="section-label">Manufacturing Excellence</p>
                <h2 class="section-title">Inside Our Facilities</h2>
                <p class="section-description">
                    State-of-the-art manufacturing equipment and quality control processes that ensure every bearing
                    meets our exacting standards.
                </p>
            </div>
        </div>
        <div class="carousel-wrapper">
            <div class="carousel-container">
                <div class="carousel-track" id="showcaseTrack">
                    <?php
                    $images = get_post_meta( 4713, '_gallery_images', true );

                    foreach ($images as $image) {
                        $image_url = wp_get_attachment_image_url( $image, 'full' );  ?>

                        <div class="carousel-item">
                        <div class="carousel-image">
                            <div class="carousel-image-placeholder"
                                style="background: linear-gradient(135deg, #1D4E89 0%, #2a5f9e 100%);">
                                <img src="<?php echo $image_url; ?>" alt="">
                            </div>
                        </div>
                        <div class="carousel-caption">
                            <h3><?php echo get_the_title( $image ); ?></h3>
                            <p><?php echo get_post_field( 'post_content',$image ); ?></p>
                        </div>
                    </div>
                <?php    }

                     ?>
                    
                </div>
            </div>
            <div class="carousel-nav">
                <button class="carousel-btn carousel-btn-prev" id="showcasePrev" aria-label="Previous images">
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M15 18L9 12L15 6" stroke="currentColor" stroke-width="2" stroke-linecap="round"
                            stroke-linejoin="round" />
                    </svg>
                </button>
                <button class="carousel-btn carousel-btn-next" id="showcaseNext" aria-label="Next images">
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M9 18L15 12L9 6" stroke="currentColor" stroke-width="2" stroke-linecap="round"
                            stroke-linejoin="round" />
                    </svg>
                </button>
            </div>
            <div class="carousel-indicators" id="showcaseIndicators"></div>
        </div>
    </section>

    <!-- News Section -->
    <section class="news-section">
        <div class="container">
            <div class="section-header">
                <p class="section-label">Latest Updates</p>
                <h2 class="section-title">Industry News & Insights</h2>
                <p class="section-description">
                    Stay informed about our latest innovations, industry developments, and technical insights from our
                    engineering team.
                </p>
            </div>

            <div class="news-grid">
                <?php 
                $sticky_posts = get_option('sticky_posts');

                $args = array(
                    'post_type'  => 'post',
                    'posts_per_page'  => 4,
                    'ignore_sticky_posts'  => 0,
                    // order by default

                );
                $query = new WP_Query($args);

                while ($query->have_posts()) {
                    $query->the_post(); 
                    $is_sticky = in_array(get_the_ID(), $sticky_posts);
                    if ($is_sticky) { ?>

                        <div class="news-card featured">
                            <div class="news-image">
                                <div class="news-image-placeholder"
                                    style="background: linear-gradient(135deg, #1D4E89 0%, #2a5f9e 100%);">
                                    <?php the_post_thumbnail(); ?>
                                </div>
                                <span class="news-badge featured-badge">Featured</span>
                            </div>
                            <div class="news-content">
                                <div class="news-meta">
                                    <span class="news-category"><?php echo get_the_category_list(', '); ?></span>
                                    <span class="news-date"><?php echo the_time(get_option('date_format')); ?></span>
                                </div>
                                <h3 class="news-title"><?php the_title(); ?></h3>
                                <p class="news-excerpt">
                                    <?php echo mb_strimwidth(strip_tags(get_the_content()), 0,100) ?>
                                </p>
                                <a href="<?php the_permalink(  ); ?>" class="news-link">Read Full Article →</a>
                            </div>
                        </div>
                        
                <?php    } else { ?>

                    <div class="news-card">
                    <div class="news-image">
                        <div class="news-image-placeholder"
                            style="background: linear-gradient(135deg, #333333 0%, #555555 100%);">
                            <?php the_post_thumbnail(); ?>
                        </div>
                        <span class="news-badge">Press Release</span>
                    </div>
                    <div class="news-content">
                        <div class="news-meta">
                            <span class="news-category"><?php echo get_the_category_list(); ?></span>
                            <span class="news-date"><?php echo the_time(get_option('date_format')); ?></span>
                        </div>
                        <h3 class="news-title"><?php the_title(); ?></h3>
                        <p class="news-excerpt">
                            <?php echo mb_strimwidth(strip_tags(get_the_content()), 0, 100) ?>
                        </p>
                        <a href="<?php the_permalink(  ); ?>" class="news-link">Read More →</a>
                    </div>
                </div>


              <?php  }

                    ?>

                    
             <?php   }

                 ?>
                
            </div>
            <div class="news-cta">
                <a href="<?php echo home_url('/news'); ?>" class="btn btn-secondary">View All News & Updates</a>
            </div>
        </div>
    </section>

    <!-- CTA Section -->
    <?php 
    foreach ($blocks as $block) {
        if (isset($block['blockName']) && $block['blockName'] === 'custom/cta-block'):
        echo render_block($block);
        break;
    endif;
    } ?>

<?php

get_footer();
