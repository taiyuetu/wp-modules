<?php
/**
 * Enqueue scripts and styles.
 *
 * @package WP_Starter
 */

if (!defined('ABSPATH')) {
	exit;
}

/**
 * Enqueue frontend assets.
 */
function wp_starter_scripts()
{
	// Enqueue Google Fonts
	wp_enqueue_style('wp-starter-fonts', 'https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&family=Montserrat:wght@400;500;600;700&display=swap', array(), null);

	wp_enqueue_style('wp-starter-style', get_stylesheet_uri(), array(), WP_STARTER_VERSION);
	wp_enqueue_style('wp-starter-styles', get_template_directory_uri() . '/assets/css/styles.css', array(), WP_STARTER_VERSION);

	wp_enqueue_style('product-page-style', get_template_directory_uri() . '/assets/css/products-page.css');

	if (is_singular('product')) {

		wp_enqueue_style('single-product-style', get_template_directory_uri() . '/assets/css/product-detail.css', array(), WP_STARTER_VERSION);

		wp_enqueue_script('tqb-single-product-script', get_template_directory_uri() . '/assets/js/product-detail.js', array(), WP_STARTER_VERSION, true);
	}

	wp_enqueue_script('wp-starter-script', get_template_directory_uri() . '/assets/js/script.js', array(), WP_STARTER_VERSION, true);
}
add_action('wp_enqueue_scripts', 'wp_starter_scripts');
