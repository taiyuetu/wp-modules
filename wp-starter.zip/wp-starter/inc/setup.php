<?php
/**
 * Theme setup.
 *
 * @package WP_Starter
 */

if (!defined('ABSPATH')) {
	exit;
}

if (!function_exists('wp_starter_setup')) {
	/**
	 * Sets up theme defaults and registers support for various WordPress features.
	 */
	function wp_starter_setup()
	{
		load_theme_textdomain('wp-starter', get_template_directory() . '/languages');

		add_theme_support('automatic-feed-links');
		add_theme_support('title-tag');
		add_theme_support('post-thumbnails');
		add_theme_support('html5', array('search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script'));
		add_theme_support('custom-logo', array('height' => 80, 'width' => 240, 'flex-height' => true, 'flex-width' => true));
		add_theme_support('customize-selective-refresh-widgets');

		register_nav_menus(
			array(
			'primary' => esc_html__('Primary Menu', 'wp-starter'),
			'footer' => esc_html__('Footer Menu', 'wp-starter'),
		)
		);
	}
}
add_action('after_setup_theme', 'wp_starter_setup');

/**
 * Set the content width in pixels.
 */
function wp_starter_content_width()
{
	$GLOBALS['content_width'] = apply_filters('wp_starter_content_width', 800);
}
add_action('after_setup_theme', 'wp_starter_content_width', 0);

/**
 * Register widget area.
 */
// function wp_starter_widgets_init() {
// 	register_sidebar(
// 		array(
// 			'name'          => esc_html__( 'Sidebar', 'wp-starter' ),
// 			'id'            => 'sidebar-1',
// 			'description'   => esc_html__( 'Add widgets here.', 'wp-starter' ),
// 			'before_widget' => '<section id="%1$s" class="widget %2$s">',
// 			'after_widget'  => '</section>',
// 			'before_title'  => '<h2 class="widget-title">',
// 			'after_title'   => '</h2>',
// 		)
// 	);
// }
// add_action( 'widgets_init', 'wp_starter_widgets_init' );

