<?php
/**
 * Footer Brand Widget
 * 
 * Displays a footer logo (from theme options) and a dynamic description.
 * Register via functions.php: add_action('widgets_init', function(){ register_widget('Footer_Brand_Widget'); });
 */

if ( ! defined( 'ABSPATH' ) ) exit;

class Footer_Brand_Widget extends WP_Widget {

    public function __construct() {
        parent::__construct(
            'footer_brand_widget',
            __( 'Footer Brand', 'your-theme' ),
            [
                'description' => __( 'Displays the footer logo and a short brand description.', 'your-theme' ),
                'classname'   => 'footer-column',
            ]
        );
    }

    /**
     * Front-end display
     */
    public function widget( $args, $instance ) {
        echo $args['before_widget'];

        // ── Logo ──────────────────────────────────────────────────────────────
        // Priority order:
        //   1. Widget-level logo (set in widget settings)
        //   2. Theme option (ACF / Customizer / custom option)
        //   3. WordPress custom logo (Customizer → Site Identity)

        $logo_id = ! empty( $instance['logo_id'] ) ? absint( $instance['logo_id'] ) : 0;

        if ( ! $logo_id ) {
            // ── Try theme options (ACF field example) ──
            if ( function_exists( 'get_field' ) ) {
                $acf_logo = get_field( 'footer_logo', 'option' );  // ACF Options Page
                if ( ! empty( $acf_logo['id'] ) ) {
                    $logo_id = absint( $acf_logo['id'] );
                }
            }

            // ── Try Customizer theme_mod ──
            if ( ! $logo_id ) {
                $logo_id = absint( get_theme_mod( 'footer_logo', 0 ) );
            }

            // ── Fall back to WordPress custom logo ──
            if ( ! $logo_id ) {
                $logo_id = absint( get_theme_mod( 'custom_logo', 0 ) );
            }
        }

        // ── Description ───────────────────────────────────────────────────────
        $description = ! empty( $instance['description'] )
            ? sanitize_text_field( $instance['description'] )
            : '';

        // ── Render ────────────────────────────────────────────────────────────
        ?>
        <div class="footer-logo">
            <?php if ( $logo_id ) : ?>
                <?php
                echo wp_get_attachment_image(
                    $logo_id,
                    'full',
                    false,
                    [
                        'class' => 'footer-logo__img',
                        'alt'   => esc_attr( get_bloginfo( 'name' ) ),
                        'loading' => 'lazy',
                    ]
                );
                ?>
            <?php else : ?>
                <img src="<?php echo ws_get_option('footer_logo'); ?>" alt="<?php bloginfo( 'name' ); ?>">
            <?php endif; ?>
        </div>

        <?php if ( $description ) : ?>
            <p class="footer-description"><?php echo esc_html( $description ); ?></p>
        <?php endif; ?>

        <?php
        echo $args['after_widget'];
    }

    /**
     * Back-end widget form (WordPress admin)
     */
    public function form( $instance ) {
        $logo_id     = ! empty( $instance['logo_id'] )    ? absint( $instance['logo_id'] )                 : 0;
        $logo_url    = $logo_id ? wp_get_attachment_image_url( $logo_id, 'thumbnail' ) : '';
        $description = ! empty( $instance['description'] ) ? esc_attr( $instance['description'] ) : '';
        ?>

        <!-- Logo Upload -->
        <p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'logo_id' ) ); ?>">
                <?php esc_html_e( 'Footer Logo (overrides theme option):', 'your-theme' ); ?>
            </label>
        </p>
        <div class="footer-brand-widget-logo-wrap">
            <?php if ( $logo_url ) : ?>
                <img src="<?php echo esc_url( $logo_url ); ?>"
                     style="max-width:100%;margin-bottom:8px;display:block;" alt="">
            <?php endif; ?>
            <input type="hidden"
                   id="<?php echo esc_attr( $this->get_field_id( 'logo_id' ) ); ?>"
                   name="<?php echo esc_attr( $this->get_field_name( 'logo_id' ) ); ?>"
                   value="<?php echo esc_attr( $logo_id ); ?>" />
            <button type="button"
                    class="button footer-brand-widget-upload-btn"
                    data-field-id="<?php echo esc_attr( $this->get_field_id( 'logo_id' ) ); ?>">
                <?php esc_html_e( $logo_id ? 'Change Logo' : 'Upload Logo', 'your-theme' ); ?>
            </button>
            <?php if ( $logo_id ) : ?>
                <button type="button"
                        class="button footer-brand-widget-remove-btn"
                        data-field-id="<?php echo esc_attr( $this->get_field_id( 'logo_id' ) ); ?>">
                    <?php esc_html_e( 'Remove', 'your-theme' ); ?>
                </button>
            <?php endif; ?>
        </div>
        <p style="font-style:italic;color:#666;font-size:11px;">
            <?php esc_html_e( 'Leave blank to use the logo from your theme options or Customizer.', 'your-theme' ); ?>
        </p>

        <!-- Description -->
        <p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'description' ) ); ?>">
                <?php esc_html_e( 'Description:', 'your-theme' ); ?>
            </label>
            <textarea id="<?php echo esc_attr( $this->get_field_id( 'description' ) ); ?>"
                      name="<?php echo esc_attr( $this->get_field_name( 'description' ) ); ?>"
                      rows="4"
                      class="widefat"><?php echo $description; ?></textarea>
        </p>

        <script>
        (function($){
            // Enqueue media scripts lazily (only once)
            if ( typeof wp !== 'undefined' && wp.media ) {
                $(document).on('click', '.footer-brand-widget-upload-btn', function(e){
                    e.preventDefault();
                    var btn     = $(this);
                    var fieldId = btn.data('field-id');
                    var frame   = wp.media({ title: 'Select Logo', button: { text: 'Use this logo' }, multiple: false });
                    frame.on('select', function(){
                        var attachment = frame.state().get('selection').first().toJSON();
                        $('#' + fieldId).val(attachment.id);
                        var img = btn.closest('.footer-brand-widget-logo-wrap').find('img');
                        if ( img.length ) {
                            img.attr('src', attachment.sizes.thumbnail ? attachment.sizes.thumbnail.url : attachment.url);
                        } else {
                            btn.before('<img src="' + (attachment.sizes.thumbnail ? attachment.sizes.thumbnail.url : attachment.url) + '" style="max-width:100%;margin-bottom:8px;display:block;" alt="">');
                        }
                        btn.text('Change Logo');
                    });
                    frame.open();
                });

                $(document).on('click', '.footer-brand-widget-remove-btn', function(e){
                    e.preventDefault();
                    var btn     = $(this);
                    var fieldId = btn.data('field-id');
                    $('#' + fieldId).val('');
                    btn.closest('.footer-brand-widget-logo-wrap').find('img').remove();
                    btn.closest('.footer-brand-widget-logo-wrap').find('.footer-brand-widget-upload-btn').text('Upload Logo');
                    btn.remove();
                });
            }
        }(jQuery));
        </script>
        <?php
    }

    /**
     * Sanitize & save widget options
     */
    public function update( $new_instance, $old_instance ) {
        $instance                = [];
        $instance['logo_id']     = absint( $new_instance['logo_id'] );
        $instance['description'] = sanitize_textarea_field( $new_instance['description'] );
        return $instance;
    }
}