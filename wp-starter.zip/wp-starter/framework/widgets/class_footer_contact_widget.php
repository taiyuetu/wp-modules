<?php
/**
 * Plugin Name: Footer Contact Widget
 * Description: A dynamic footer contact column widget with editable email, phone, and hours.
 * Version: 1.0.0
 * Author: Your Name
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Footer_Contact_Widget Class
 */
class Footer_Contact_Widget extends WP_Widget {

    public function __construct() {
        parent::__construct(
            'footer_contact_widget',
            __( 'Footer Contact Column', 'footer-contact-widget' ),
            array(
                'description' => __( 'Displays a footer contact column with heading, email, phone, and business hours.', 'footer-contact-widget' ),
                'classname'   => 'footer-contact-widget',
            )
        );
    }

    /**
     * Front-end display of the widget.
     *
     * @param array $args     Widget display arguments.
     * @param array $instance Saved widget settings.
     */
    public function widget( $args, $instance ) {
        $heading = ! empty( $instance['heading'] ) ? $instance['heading'] : __( 'Contact', 'footer-contact-widget' );
        $email   = ! empty( $instance['email'] )   ? $instance['email']   : '';
        $phone   = ! empty( $instance['phone'] )   ? $instance['phone']   : '';
        $hours   = ! empty( $instance['hours'] )   ? $instance['hours']   : '';

        echo $args['before_widget'];
        ?>
        <div class="footer-column">
            <h4 class="footer-heading"><?php echo esc_html( $heading ); ?></h4>
            <ul class="footer-contact">
                <?php if ( $email ) : ?>
                    <li>
                        <a href="mailto:<?php echo esc_attr( antispambot( $email ) ); ?>">
                            <?php echo esc_html( antispambot( $email ) ); ?>
                        </a>
                    </li>
                <?php endif; ?>

                <?php if ( $phone ) : ?>
                    <li>
                        <a href="tel:<?php echo esc_attr( preg_replace( '/[^\d+]/', '', $phone ) ); ?>">
                            <?php echo esc_html( $phone ); ?>
                        </a>
                    </li>
                <?php endif; ?>

                <?php if ( $hours ) : ?>
                    <li><?php echo esc_html( $hours ); ?></li>
                <?php endif; ?>
            </ul>
        </div>
        <?php
        echo $args['after_widget'];
    }

    /**
     * Back-end widget form in the WordPress admin.
     *
     * @param array $instance Previously saved widget settings.
     */
    public function form( $instance ) {
        $heading = ! empty( $instance['heading'] ) ? $instance['heading'] : __( 'Contact', 'footer-contact-widget' );
        $email   = ! empty( $instance['email'] )   ? $instance['email']   : '';
        $phone   = ! empty( $instance['phone'] )   ? $instance['phone']   : '';
        $hours   = ! empty( $instance['hours'] )   ? $instance['hours']   : '';

        $fields = array(
            'heading' => array(
                'label'       => __( 'Column Heading:', 'footer-contact-widget' ),
                'type'        => 'text',
                'value'       => $heading,
                'placeholder' => __( 'Contact', 'footer-contact-widget' ),
            ),
            'email' => array(
                'label'       => __( 'Email Address:', 'footer-contact-widget' ),
                'type'        => 'email',
                'value'       => $email,
                'placeholder' => 'email@example.com',
            ),
            'phone' => array(
                'label'       => __( 'Phone Number:', 'footer-contact-widget' ),
                'type'        => 'text',
                'value'       => $phone,
                'placeholder' => '+1 (555) 123-4567',
            ),
            'hours' => array(
                'label'       => __( 'Business Hours:', 'footer-contact-widget' ),
                'type'        => 'text',
                'value'       => $hours,
                'placeholder' => 'Mon-Fri: 8:00 AM - 6:00 PM EST',
            ),
        );

        foreach ( $fields as $key => $field ) :
            ?>
            <p>
                <label for="<?php echo esc_attr( $this->get_field_id( $key ) ); ?>">
                    <?php echo esc_html( $field['label'] ); ?>
                </label>
                <input
                    class="widefat"
                    id="<?php echo esc_attr( $this->get_field_id( $key ) ); ?>"
                    name="<?php echo esc_attr( $this->get_field_name( $key ) ); ?>"
                    type="<?php echo esc_attr( $field['type'] ); ?>"
                    value="<?php echo esc_attr( $field['value'] ); ?>"
                    placeholder="<?php echo esc_attr( $field['placeholder'] ); ?>"
                />
            </p>
            <?php
        endforeach;
    }

    /**
     * Sanitize and save widget settings.
     *
     * @param array $new_instance New widget settings.
     * @param array $old_instance Old widget settings.
     * @return array Updated settings.
     */
    public function update( $new_instance, $old_instance ) {
        $instance            = array();
        $instance['heading'] = sanitize_text_field( $new_instance['heading'] );
        $instance['email']   = sanitize_email( $new_instance['email'] );
        $instance['phone']   = sanitize_text_field( $new_instance['phone'] );
        $instance['hours']   = sanitize_text_field( $new_instance['hours'] );

        return $instance;
    }
}

/**
 * Register the widget.
 */
function register_footer_contact_widget() {
    register_widget( 'Footer_Contact_Widget' );
}
add_action( 'widgets_init', 'register_footer_contact_widget' );