<?php

function tqb_widgets_init()
{
    register_sidebar(array(
        'name' => esc_html__('Primary Sidebar', 'wp-starter'),
        'id' => 'sidebar-1',
        'description' => esc_html__('Add widgets here.', 'wp-starter'),
        'before_widget' => '<section id="%1$s" class="widget %2$s">',
        'after_widget' => '</section>',
        'before_title' => '<h2 class="widget-title">',
        'after_title' => '</h2>',
    ));

    register_sidebar(array(
        'name' => esc_html__('Product Sidebar', 'wp-starter'),
        'id' => 'product-sidebar',
        'description' => esc_html__('Add widgets for the product archive here.', 'wp-starter'),
        'before_widget' => '<section id="%1$s" class="widget %2$s">',
        'after_widget' => '</section>',
        'before_title' => '<h2 class="widget-title">',
        'after_title' => '</h2>',
    ));

    register_sidebar(array(
        'name' => esc_html__('Footer Sidebar', 'wp-starter'),
        'id' => 'footer-sidebar',
        'description' => esc_html__('Footer Sidebar', 'wp-starter'),
        'before_widget' => '<div class="footer-column">',
        'after_widget' => '</div>',
        'before_title' => '<h4 class="footer-heading">',
        'after_title' => '</h4>'
    ));

    // Register custom widgets
    register_widget('Footer_Brand_Widget');
}
add_action('widgets_init', 'tqb_widgets_init');

// Load widget class files (must be loaded before register_widget is called)
locate_template('/framework/widgets/class-footer-brand-widget.php', true, true);
locate_template('/framework/widgets/class-footer-nav-widget.php', true, true);
locate_template('/framework/widgets/class_footer_contact_widget.php', true, true);