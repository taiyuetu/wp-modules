<?php


/**
 * Displays a dynamic page header banner.
 * Handles Pages, Posts, CPTs, Taxonomies, Search, and 404s.
 */
function tqb_page_banner()
{
    $title = '';
    $description = '';

    if (is_front_page()) {
        // Front Page
        $title = get_bloginfo('name');
        $description = get_bloginfo('description');

    }
    elseif (is_home()) {
        // Blog Index Page
        $posts_page_id = get_option('page_for_posts');
        $title = $posts_page_id ? get_the_title($posts_page_id) : __('Latest Posts', 'textdomain');
        $description = get_the_archive_description();

    }
    elseif (is_singular()) {
        // Single Posts, Pages, and Custom Post Types
        $title = get_the_title();
        // Use the excerpt as description, or a custom field if preferred
        $description = has_excerpt() ? get_the_excerpt() : '';

    }
    elseif (is_archive()) {
        // Categories, Tags, Custom Taxonomies, and CPT Archives
        $title = get_the_archive_title();
        $description = get_the_archive_description();

    }
    elseif (is_search()) {
        // Search Results
        $title = sprintf(__('Search Results for: %s', 'textdomain'), '<span>' . get_search_query() . '</span>');
        $description = sprintf(__('We found results for your inquiry.', 'textdomain'));

    }
    elseif (is_404()) {
        // 404 Error Page
        $title = __('Page Not Found', 'textdomain');
        $description = __('The content you’re looking for doesn’t exist or has been moved.', 'textdomain');
    }

    // Output the HTML
    $banner_image_url = '';
    if (is_singular() || is_page() || (is_front_page() && !is_home())) {
        $banner_image_url = get_the_post_thumbnail_url(get_the_ID(), 'full');
    }
    elseif (is_home()) {
        $posts_page_id = get_option('page_for_posts');
        if ($posts_page_id) {
            $banner_image_url = get_the_post_thumbnail_url($posts_page_id, 'full');
        }
    }

    $header_style = '';
    if ($banner_image_url) {
        $header_style = ' style="background-image: url(\'' . esc_url($banner_image_url) . '\'); background-size: cover; background-position: center center;"';
    }
?>
    <section class="page-header"<?php //echo $header_style; ?>>
        <div class="container">
            <?php tqb_breadcrumbs(); ?>
            <h1 class="page-title"><?php echo wp_kses_post($title); ?></h1>
            <?php if ($description): ?>
                <div class="page-description">
                    <?php echo wp_kses_post(wpautop($description)); ?>
                </div>
            <?php
    endif; ?>
        </div>
    </section>
    <?php
}


function tqb_breadcrumbs()
{
    $separator = '<span class="separator">/</span>';
    $home_title = 'Home';

    global $post;

    echo '<div class="breadcrumb">';
    echo '<a href="' . get_home_url() . '">' . $home_title . '</a>';

    if (!is_front_page()) {
        echo $separator;

        // 1. CUSTOM POST TYPE ARCHIVE
        if (is_post_type_archive()) {
            echo '<span>' . post_type_archive_title('', false) . '</span>';
        }

        // 2. CUSTOM TAXONOMY ARCHIVE (e.g., genre, department)
        elseif (is_tax()) {
            $queried_object = get_queried_object();
            // Optional: Link to the CPT archive if it exists
            $post_type = get_taxonomy($queried_object->taxonomy)->object_type[0];
            $post_type_obj = get_post_type_object($post_type);

            echo '<a href="' . get_post_type_archive_link($post_type) . '">' . $post_type_obj->labels->name . '</a>';
            echo $separator;
            echo '<span>' . $queried_object->name . '</span>';
        }

        // 3. SINGLE POSTS (Standard & Custom)
        elseif (is_singular()) {
            $post_type = get_post_type();

            // If it's a CPT, show the Archive link first
            if ($post_type != 'post' && $post_type != 'page') {
                $post_type_obj = get_post_type_object($post_type);
                echo '<a href="' . get_post_type_archive_link($post_type) . '">' . $post_type_obj->labels->name . '</a>';
                echo $separator;

                // Optional: Show the first term of a custom taxonomy if available
                $taxonomies = get_object_taxonomies($post_type);
                if (!empty($taxonomies)) {
                    $terms = get_the_terms($post->ID, $taxonomies[0]);
                    if ($terms && !is_wp_error($terms)) {
                        echo '<a href="' . get_term_link($terms[0]) . '">' . $terms[0]->name . '</a>';
                        echo $separator;
                    }
                }
            }

            // If it's a standard Post, show Category
            elseif ($post_type == 'post') {
                $category = get_the_category();
                if ($category) {
                    echo '<a href="' . get_category_link($category[0]->term_id) . '">' . $category[0]->cat_name . '</a>';
                    echo $separator;
                }
            }

            echo '<span>' . get_the_title() . '</span>';
        }

        // 4. STANDARD PAGES (with Parent Support)
        elseif (is_page()) {
            if ($post->post_parent) {
                $anc = array_reverse(get_post_ancestors($post->ID));
                foreach ($anc as $ancestor) {
                    echo '<a href="' . get_permalink($ancestor) . '">' . get_the_title($ancestor) . '</a>';
                    echo $separator;
                }
            }
            echo '<span>' . get_the_title() . '</span>';
        }

        // 5. BLOG/CATEGORY/TAG/SEARCH/404 (Standard WP)
        elseif (is_category()) {
            echo '<span>' . single_cat_title('', false) . '</span>';
        }
        elseif (is_tag()) {
            echo '<span>' . single_tag_title('', false) . '</span>';
        }
        elseif (is_search()) {
            echo '<span>Search: ' . get_search_query() . '</span>';
        }
        elseif (is_404()) {
            echo '<span>404 Not Found</span>';
        }
    }

    echo '</div>';
}


/**
 * Remove the "Category:", "Tag:", or "Archives:" prefix from archive titles.
 */
add_filter('get_the_archive_title_prefix', '__return_false');


function product_review_starts() {  ?>

    <div class="stars">
                            <svg width="20" height="20" viewBox="0 0 20 20" fill="#FFA500" xmlns="http://www.w3.org/2000/svg">
                                <path d="M10 1L12.472 7.236L19 8.09L14.5 12.382L15.708 19L10 15.764L4.292 19L5.5 12.382L1 8.09L7.528 7.236L10 1Z"></path>
                            </svg>
                            <svg width="20" height="20" viewBox="0 0 20 20" fill="#FFA500" xmlns="http://www.w3.org/2000/svg">
                                <path d="M10 1L12.472 7.236L19 8.09L14.5 12.382L15.708 19L10 15.764L4.292 19L5.5 12.382L1 8.09L7.528 7.236L10 1Z"></path>
                            </svg>
                            <svg width="20" height="20" viewBox="0 0 20 20" fill="#FFA500" xmlns="http://www.w3.org/2000/svg">
                                <path d="M10 1L12.472 7.236L19 8.09L14.5 12.382L15.708 19L10 15.764L4.292 19L5.5 12.382L1 8.09L7.528 7.236L10 1Z"></path>
                            </svg>
                            <svg width="20" height="20" viewBox="0 0 20 20" fill="#FFA500" xmlns="http://www.w3.org/2000/svg">
                                <path d="M10 1L12.472 7.236L19 8.09L14.5 12.382L15.708 19L10 15.764L4.292 19L5.5 12.382L1 8.09L7.528 7.236L10 1Z"></path>
                            </svg>
                            <svg width="20" height="20" viewBox="0 0 20 20" fill="#FFA500" xmlns="http://www.w3.org/2000/svg">
                                <path d="M10 1L12.472 7.236L19 8.09L14.5 12.382L15.708 19L10 15.764L4.292 19L5.5 12.382L1 8.09L7.528 7.236L10 1Z"></path>
                            </svg>
                           
                        </div>

<?php }