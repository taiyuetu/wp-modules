<?php

/**
 * Enable SVG Uploads
 */
function wps_enable_svg_upload($mimes)
{
    $mimes['svg'] = 'image/svg+xml';
    return $mimes;
}
add_filter('upload_mimes', 'wps_enable_svg_upload');

/**
 * Fix SVG display in WordPress Media Library
 */
function wps_fix_svg_thumb_display()
{
    echo '<style>
		td.media-icon img[src$=".svg"], img[src$=".svg"].attachment-post-thumbnail {
			width: 100% !important;
			height: auto !important;
		}
	</style>';
}
add_action('admin_head', 'wps_fix_svg_thumb_display');

/**
 * Get theme option using WP Rapid Fields framework.
 *
 * @param string $option_name
 * @param mixed $default
 * @return mixed
 */
if (!function_exists('ws_get_option')) {
    function ws_get_option($option_name, $default = '')
    {
        // Fetch options array saved by WP Rapid Fields ('tqb_options' + '_opts')
        $options = get_option('tqb_options_opts', []);

        if (isset($options[$option_name]) && $options[$option_name] !== '') {
            return $options[$option_name];
        }

        return $default;
    }
}