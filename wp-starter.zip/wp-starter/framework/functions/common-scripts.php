<?php

function wp_starter_enqueue_all_assets()
{
    $theme_dir = get_template_directory();
    $theme_uri = get_template_directory_uri();

    // Enqueue all CSS files from assets/css/
    $css_dir = $theme_dir . '/assets/css/';
    if (is_dir($css_dir)) {
        foreach (glob($css_dir . '*.css') as $file) {
            $filename = basename($file);
            $handle = 'wp-starter-css-' . basename($filename, '.css');
            $version = file_exists($file) ? filemtime($file) : (defined('WP_STARTER_VERSION') ? WP_STARTER_VERSION : '1.0.0');
            wp_enqueue_style($handle, $theme_uri . '/assets/css/' . $filename, array(), $version);
        }
    }

    // Enqueue all JS files from assets/js/
    $js_dir = $theme_dir . '/assets/js/';
    if (is_dir($js_dir)) {
        foreach (glob($js_dir . '*.js') as $file) {
            $filename = basename($file);
            $handle = 'wp-starter-js-' . basename($filename, '.js');
            $version = file_exists($file) ? filemtime($file) : (defined('WP_STARTER_VERSION') ? WP_STARTER_VERSION : '1.0.0');
            // Enqueue JS in the footer (true)
            wp_enqueue_script($handle, $theme_uri . '/assets/js/' . $filename, array('jquery'), $version, true);
        }
    }
}
add_action('wp_enqueue_scripts', 'wp_starter_enqueue_all_assets');
