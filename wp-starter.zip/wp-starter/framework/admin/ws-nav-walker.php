<?php
/**
 * Custom Nav Walker
 *
 * Renders the nav menu with:
 *  - Top-level items as <li class="nav-item [has-dropdown]">
 *  - Top-level links as <a class="nav-link">  (with inline SVG chevron when children exist)
 *  - Sub-menus as <ul class="dropdown-menu"> with <a class="dropdown-link"> children
 *  - Last top-level item (CTA) as <a class="nav-cta">
 *
 * To mark a menu item as the CTA button, add the CSS class "nav-cta" to it
 * in Appearance → Menus (Screen Options → CSS Classes must be enabled).
 */

if (!defined('ABSPATH')) {
    exit;
}

class Custom_Nav_Walker extends Walker_Nav_Menu
{

    /**
     * SVG chevron used on parent items.
     */
    private function chevron_svg(): string
    {
        return '<svg class="dropdown-icon" width="12" height="12" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">'
            . '<path d="M3 4.5L6 7.5L9 4.5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>'
            . '</svg>';
    }

    /**
     * Opens a <li> element for each menu item.
     *
     * @param string   $output  Passed by reference.
     * @param WP_Post  $item    Menu item data object.
     * @param int      $depth   Depth of menu item (0 = top-level).
     * @param stdClass $args    Walker args.
     * @param int      $id      Current item ID.
     */
    public function start_el(&$output, $item, $depth = 0, $args = null, $id = 0)
    {

        $indent = str_repeat("\t", $depth);

        // ── Extra classes set in the WP menu editor ──────────────────────────
        $item_classes = empty($item->classes) ? [] : (array)$item->classes;
        $item_classes = array_filter($item_classes);

        // Detect CTA: editor added "nav-cta" class to the item itself
        $is_cta = in_array('nav-cta', $item_classes, true);

        // Has children? (Walker_Nav_Menu sets 'menu-item-has-children')
        $has_children = in_array('menu-item-has-children', $item_classes, true);

        if ($depth === 0) {
            // ── Top-level <li> ────────────────────────────────────────────────
            $li_classes = ['nav-item'];
            if ($has_children) {
                $li_classes[] = 'has-dropdown';
            }
            if ($item->current || $item->current_item_ancestor) {
                $li_classes[] = 'current-menu-item';
            }

            $output .= "\n{$indent}<li class=\"" . esc_attr(implode(' ', $li_classes)) . '">';

            // Link classes
            $link_class = $is_cta ? 'nav-cta' : 'nav-link';

            $atts = [
                'href' => !empty($item->url) ? esc_url($item->url) : '#',
                'class' => $link_class,
                'title' => !empty($item->attr_title) ? esc_attr($item->attr_title) : '',
                'target' => !empty($item->target) ? esc_attr($item->target) : '',
                'rel' => !empty($item->xfn) ? esc_attr($item->xfn) : '',
            ];

            if ($item->current) {
                $atts['aria-current'] = 'page';
            }

            $atts_html = '';
            foreach ($atts as $attr => $val) {
                if ($val !== '') {
                    $atts_html .= " {$attr}=\"{$val}\"";
                }
            }

            $title = apply_filters('the_title', $item->title, $item->ID);
            $chevron = ($has_children && !$is_cta) ? "\n\t\t\t\t" . $this->chevron_svg() . "\n\t\t\t" : '';

            $output .= "\n\t{$indent}<a{$atts_html}>\n\t\t{$indent}{$title}{$chevron}</a>";

        }
        else {
            // ── Dropdown <li> ─────────────────────────────────────────────────
            $output .= "\n{$indent}<li>";

            $atts = [
                'href' => !empty($item->url) ? esc_url($item->url) : '#',
                'class' => 'dropdown-link',
                'title' => !empty($item->attr_title) ? esc_attr($item->attr_title) : '',
                'target' => !empty($item->target) ? esc_attr($item->target) : '',
                'rel' => !empty($item->xfn) ? esc_attr($item->xfn) : '',
            ];

            if ($item->current) {
                $atts['aria-current'] = 'page';
            }

            $atts_html = '';
            foreach ($atts as $attr => $val) {
                if ($val !== '') {
                    $atts_html .= " {$attr}=\"{$val}\"";
                }
            }

            $title = apply_filters('the_title', $item->title, $item->ID);
            $output .= "<a{$atts_html}>{$title}</a>";
        }
    }

    /**
     * Closes a <li> element.
     */
    public function end_el(&$output, $item, $depth = 0, $args = null)
    {
        $output .= "</li>\n";
    }

    /**
     * Opens a sub-menu <ul>.
     */
    public function start_lvl(&$output, $depth = 0, $args = null)
    {
        $indent = str_repeat("\t", $depth + 1);
        $output .= "\n{$indent}<ul class=\"dropdown-menu\">\n";
    }

    /**
     * Closes a sub-menu <ul>.
     */
    public function end_lvl(&$output, $depth = 0, $args = null)
    {
        $indent = str_repeat("\t", $depth + 1);
        $output .= "{$indent}</ul>\n";
    }
}