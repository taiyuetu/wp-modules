<?php
/**
 * Register Custom Post Type: Product
 * Register Custom Taxonomy: Product Category
 */

// -----------------------------------------------
// 1. Register Custom Post Type: product
// -----------------------------------------------
function register_product_post_type()
{
    $labels = [
        'name' => _x('Products', 'Post type general name', 'textdomain'),
        'singular_name' => _x('Product', 'Post type singular name', 'textdomain'),
        'menu_name' => _x('Products', 'Admin Menu text', 'textdomain'),
        'name_admin_bar' => _x('Product', 'Add New on Toolbar', 'textdomain'),
        'add_new' => __('Add New', 'textdomain'),
        'add_new_item' => __('Add New Product', 'textdomain'),
        'new_item' => __('New Product', 'textdomain'),
        'edit_item' => __('Edit Product', 'textdomain'),
        'view_item' => __('View Product', 'textdomain'),
        'all_items' => __('All Products', 'textdomain'),
        'search_items' => __('Search Products', 'textdomain'),
        'not_found' => __('No products found.', 'textdomain'),
        'not_found_in_trash' => __('No products found in Trash.', 'textdomain'),
        'featured_image' => __('Product Image', 'textdomain'),
        'set_featured_image' => __('Set product image', 'textdomain'),
        'remove_featured_image' => __('Remove product image', 'textdomain'),
        'use_featured_image' => __('Use as product image', 'textdomain'),
        'archives' => __('Product Archives', 'textdomain'),
        'insert_into_item' => __('Insert into product', 'textdomain'),
        'uploaded_to_this_item' => __('Uploaded to this product', 'textdomain'),
    ];

    $args = [
        'labels' => $labels,
        'public' => true,
        'publicly_queryable' => true,
        'show_ui' => true,
        'show_in_menu' => true,
        'show_in_rest' => true, // Enables Gutenberg & REST API support
        'query_var' => true,
        'rewrite' => ['slug' => 'products'],
        'capability_type' => 'post',
        'has_archive' => true,
        'hierarchical' => false,
        'menu_position' => 5,
        'menu_icon' => 'dashicons-cart',
        'supports' => ['title', 'editor', 'thumbnail', 'excerpt', 'custom-fields'],
        'taxonomies' => ['product_category', 'post_tag'],
    ];

    register_post_type('product', $args);
}
add_action('init', 'register_product_post_type');


// -----------------------------------------------
// 2. Register Custom Taxonomy: product_category
// -----------------------------------------------
function register_product_category_taxonomy()
{
    $labels = [
        'name' => _x('Product Categories', 'Taxonomy general name', 'textdomain'),
        'singular_name' => _x('Product Category', 'Taxonomy singular name', 'textdomain'),
        'search_items' => __('Search Product Categories', 'textdomain'),
        'all_items' => __('All Product Categories', 'textdomain'),
        'parent_item' => __('Parent Product Category', 'textdomain'),
        'parent_item_colon' => __('Parent Product Category:', 'textdomain'),
        'edit_item' => __('Edit Product Category', 'textdomain'),
        'update_item' => __('Update Product Category', 'textdomain'),
        'add_new_item' => __('Add New Product Category', 'textdomain'),
        'new_item_name' => __('New Product Category Name', 'textdomain'),
        'menu_name' => __('Product Categories', 'textdomain'),
        'not_found' => __('No product categories found.', 'textdomain'),
        'back_to_items' => __('← Go to Product Categories', 'textdomain'),
    ];

    $args = [
        'labels' => $labels,
        'hierarchical' => true, // true = like Categories; false = like Tags
        'public' => true,
        'show_ui' => true,
        'show_admin_column' => true, // Shows taxonomy column in post list
        'show_in_rest' => true, // Enables Gutenberg & REST API support
        'query_var' => true,
        'rewrite' => ['slug' => 'product-category'],
    ];

    register_taxonomy('product_category', ['product'], $args);
}

add_action('init', 'register_product_category_taxonomy');


// -----------------------------------------------
// 3. Register Custom Post Type: download
// -----------------------------------------------
function register_download_post_type()
{
    $labels = [
        'name' => _x('Downloads', 'Post type general name', 'textdomain'),
        'singular_name' => _x('Download', 'Post type singular name', 'textdomain'),
        'menu_name' => _x('Downloads', 'Admin Menu text', 'textdomain'),
        'name_admin_bar' => _x('Download', 'Add New on Toolbar', 'textdomain'),
        'add_new' => __('Add New', 'textdomain'),
        'add_new_item' => __('Add New Download', 'textdomain'),
        'new_item' => __('New Download', 'textdomain'),
        'edit_item' => __('Edit Download', 'textdomain'),
        'view_item' => __('View Download', 'textdomain'),
        'all_items' => __('All Downloads', 'textdomain'),
        'search_items' => __('Search Downloads', 'textdomain'),
        'not_found' => __('No downloads found.', 'textdomain'),
        'not_found_in_trash' => __('No downloads found in Trash.', 'textdomain'),
        'featured_image' => __('Download Image', 'textdomain'),
        'set_featured_image' => __('Set download image', 'textdomain'),
        'remove_featured_image' => __('Remove download image', 'textdomain'),
        'use_featured_image' => __('Use as download image', 'textdomain'),
        'archives' => __('Download Archives', 'textdomain'),
        'insert_into_item' => __('Insert into download', 'textdomain'),
        'uploaded_to_this_item' => __('Uploaded to this download', 'textdomain'),
    ];

    $args = [
        'labels' => $labels,
        'public' => false,
        'publicly_queryable' => false,
        'show_ui' => true,
        'show_in_menu' => true,
        'show_in_rest' => true,
        'query_var' => true,
        'rewrite' => ['slug' => 'downloads'],
        'capability_type' => 'post',
        'has_archive' => false,
        'hierarchical' => false,
        'menu_position' => 6,
        'menu_icon' => 'dashicons-download',
        'supports' => ['title', 'editor', 'thumbnail', 'excerpt'],
    ];

    register_post_type('download', $args);
}
add_action('init', 'register_download_post_type');
