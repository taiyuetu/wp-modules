<?php
/**
 * Initialize WP Rapid Fields for Theme Options
 * /**
 * 添加了新的字段关联函数
 * Bidirectional Sync for Product and Download
 * When you link a Download to a Product, the Product is automatically added to the Download's list.
 
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

if (class_exists('WP_Rapid_Fields_Pro')) {

    // Configuration for the Options Page
    $config = [
        'id' => 'tqb_options', // Unique ID for the options page
        'title' => 'Theme Options', // Page Title
        'context' => 'option', // Setting this to 'option' creates an Admin Page
    ];

    // Define Tabs and Fields
    $tabs = [
        'general' => [
            'label' => 'General Information',
            'fields' => [
                [
                    'type' => 'heading',
                    'label' => 'Brand Identity'
                ],
                [
                    'id' => 'site_logo',
                    'type' => 'image',
                    'label' => 'Main Logo',
                    'desc' => 'Upload the main logo for the site.',
                    'return' => 'url',
                ],
                [
                    'id' => 'footer_logo',
                    'type' => 'image',
                    'label' => 'Footer Logo',
                    'desc' => 'Upload the footer logo for the site.',
                    'return' => 'url',
                ],
                [
                    'id' => 'company_profile_image',
                    'type' => 'image',
                    'label' => 'Company Profile Image',
                    'desc' => 'Upload a profile image for the company (shown on the hero section).',
                    'return' => 'url',
                ],
                [
                    'id' => 'site_logo_sticky',
                    'type' => 'image',
                    'label' => 'Sticky Header Logo',
                    'desc' => 'Upload a specific logo for sticky header if needed.',
                    'return' => 'id',
                ],
                [
                    'id' => 'site_favicon',
                    'type' => 'image',
                    'label' => 'Favicon',
                    'desc' => 'Upload a 512x512 icon.',
                    'return' => 'id',
                ],
                [
                    'id' => 'product_feature',
                    'type' => 'set',
                    'label' => 'Product Feature',
                ]
            ]
        ],
        'contact' => [
            'label' => 'Contact',
            'fields' => [
                [
                    'type' => 'heading',
                    'label' => 'Contact Information'
                ],
                [
                    'id' => 'company_phone',
                    'type' => 'text',
                    'label' => 'Phone Number',
                    'placeholder' => '+1 234 567 890',
                ],
                [
                    'id' => 'company_email',
                    'type' => 'email',
                    'label' => 'Email Address',
                    'placeholder' => 'info@example.com',
                ],
                [
                    'id' => 'company_address',
                    'type' => 'textarea',
                    'label' => 'Physical Address',
                ],
                [
                    'id' => 'google_map_embed',
                    'type' => 'textarea',
                    'label' => 'Google Maps Embed Code',
                    'desc' => 'Paste the iframe code from Google Maps here.',
                ],
            ]
        ],
        'social' => [
            'label' => 'Social Links',
            'fields' => [
                [
                    'id' => 'social_links',
                    'type' => 'group',
                    'label' => 'Social Links',
                    'desc' => 'Add your social media profiles. You can paste SVG code directly for the icons.',
                    'button' => 'Add Social Link',
                    'sub_fields' => [
                        [
                            'id' => 'title',
                            'type' => 'text',
                            'label' => 'Platform Name',
                            'placeholder' => 'e.g. Facebook',
                        ],
                        [
                            'id' => 'url',
                            'type' => 'url',
                            'label' => 'Link URL',
                            'placeholder' => 'https://...',
                        ],
                        [
                            'id' => 'icon',
                            'type' => 'textarea',
                            'label' => 'SVG Icon Code',
                            'desc' => 'Paste the <svg> code here. <br><strong>Tip:</strong> Ensure the SVG has <code>width="18" height="18"</code> and <code>fill="currentColor"</code> for best results.',
                        ],
                    ]
                ],
            ]
        ],
        'Homepage' => [
            'label' => 'Homepage',
            'fields' => [
                [
                    'type' => 'heading',
                    'label' => 'Hero Section'
                ],
                [
                    'id' => 'homepage_slider',
                    'type' => 'group',
                    'label' => 'Slider Slides',
                    'button' => 'Add Slide',
                    'sub_fields' => [
                        [
                            'id' => 'slide_tag',
                            'type' => 'text',
                            'label' => 'Tag',
                        ],
                        [
                            'id' => 'slide_title',
                            'type' => 'text',
                            'label' => 'Title',
                        ],
                        [
                            'id' => 'slide_desc',
                            'type' => 'textarea',
                            'label' => 'Description',
                        ],
                        [
                            'id' => 'slide_btn_text',
                            'type' => 'text',
                            'label' => 'Button Text',
                        ],
                        [
                            'id' => 'slide_btn_url',
                            'type' => 'text',
                            'label' => 'Button URL',
                        ],
                        [
                            'id' => 'slide_image',
                            'type' => 'image',
                            'label' => 'Slide Image',
                            'return' => 'url',
                        ],
                    ]
                ],
                [
                    'type' => 'heading',
                    'label' => 'Products Section'
                ],
                [
                    'id' => 'products_tag',
                    'type' => 'text',
                    'label' => 'Section Tag',
                    'default' => 'Product Categories',
                ],
                [
                    'id' => 'products_title',
                    'type' => 'text',
                    'label' => 'Section Title',
                    'default' => 'Engineered for Global Markets',
                ],
                [
                    'id' => 'products_desc',
                    'type' => 'textarea',
                    'label' => 'Section Description',
                    'default' => 'Comprehensive product lines designed to meet international standards and diverse market requirements.',
                ],
            ]
        ],
        'Header' => [
            'label' => 'Header',
            'fields' => [
                [
                    'id' => 'welcome_message',
                    'type' => 'text',
                    'label' => 'Welcome Message',
                    'desc' => 'Welcome message to display in the header.',
                ],
            ]
        ],
        'footer' => [
            'label' => 'Footer',
            'fields' => [
                [
                    'type' => 'heading',
                    'label' => 'Footer'
                ],
                [
                    'id' => 'whatsapp_qr',
                    'type' => 'image',
                    'label' => 'WhatsApp QR Code',
                    'desc' => 'Upload WhatsApp QR Code',
                ],
                [
                    'id' => 'wechat_qr',
                    'type' => 'image',
                    'label' => 'WeChat QR Code',
                    'desc' => 'Upload WeChat QR Code',
                ],
                [
                    'id' => 'copyright',
                    'type' => 'text',
                    'label' => 'Copyright',
                    'desc' => 'Copyright to display in the footer.',
                ],
                [
                    'id' => 'footer_text',
                    'type' => 'wp_editor',
                    'label' => 'Footer Copyright/Text',
                ],
            ]
        ],
        'Pages' => [
            'label' => 'Pages',
            'fields' => [
                [
                    'type' => 'heading',
                    'label' => 'Pages'
                ],
                [
                    'id' => 'pages',
                    'type' => 'post_select',
                    'label' => 'Pages',
                    'post_type' => 'page',
                ],
            ]
        ],
        'Products' => [
            'label' => 'Products',
            'fields' => [
                [
                    'type' => 'heading',
                    'label' => 'Products'
                ],
                [
                    'id' => 'products',
                    'type' => 'post_select',
                    'label' => 'Products',
                    'post_type' => 'product',
                ],
            ]
        ],
        'archive' => [
            'label' => 'Archive Settings',
            'fields' => [
                [
                    'type' => 'heading',
                    'label' => 'Archive Settings'
                ],
                [
                    'id' => 'archive',
                    'type' => 'post_select',
                    'label' => 'Archive',
                    'post_type' => 'archive',
                ],
            ]
        ],
        'typography' => [
            'label' => 'Typography',
            'fields' => [
                [
                    'type' => 'heading',
                    'label' => 'Typography'
                ],
                [
                    'id' => 'typography',
                    'type' => 'post_select',
                    'label' => 'Typography',
                    'post_type' => 'typography',
                ],
            ]
        ]
    ];

    // Initialize the Class
    new WP_Rapid_Fields_Pro($config, $tabs);


    // Product Post Meta Configuration
    $product_meta_config = [
        'id' => 'product_meta',
        'title' => 'Product Details',
        'context' => 'post',
        'post_types' => ['product'],
    ];

    $product_meta_tabs = [
        'gallery' => [
            'label' => 'Gallery Settings',
            'fields' => [
                [
                    'id' => 'product_gallery',
                    'type' => 'gallery',
                    'label' => 'Product Gallery',
                    'desc' => 'Select multiple images for the product gallery.',
                ],
            ]
        ],
        'property' => [
            'label' => 'Property Settings',
            'fields' => [
                [
                    'id' => 'oem_num',
                    'type' => 'text',
                    'label' => 'OEM Number',
                ],
                [
                    'id' => 'partnumber',
                    'type' => 'text',
                    'label' => 'Part Number',
                ],
                [
                    'id' => 'key_features',
                    'type' => 'set',
                    'label' => 'Key Features',

                ],
                [
                    'id' => 'drawing',
                    'type' => 'post_select',
                    'label' => 'Drawing',
                    'multiple' => true,
                    'post_type' => 'download',
                ]

            ]
        ],

    ];

    // Initialize Product Post Meta
    new WP_Rapid_Fields_Pro($product_meta_config, $product_meta_tabs);

    // Product Category Term Meta Configuration
    $category_meta_config = [
        'id' => 'category_meta',
        'title' => 'Category Settings',
        'context' => 'term',
        'taxonomy' => 'product_category',
    ];

    $category_meta_tabs = [
        'general' => [
            'label' => 'General Settings',
            'fields' => [
                [
                    'id' => 'category_cover_image',
                    'type' => 'image',
                    'label' => 'Cover Image',
                    'desc' => 'Upload a cover image for this category.',
                    'return' => 'url',
                ],
            ]
        ]
    ];

    // Initialize Product Category Term Meta
    new WP_Rapid_Fields_Pro($category_meta_config, $category_meta_tabs);

    // Download Post Meta Configuration
    $download_meta_config = [
        'id' => 'download_meta',
        'title' => 'Download Details',
        'context' => 'post',
        'post_types' => ['download'],
    ];

    $download_meta_tabs = [
        'file' => [
            'label' => 'File Settings',
            'fields' => [
                [
                    'id' => 'download_file',
                    'type' => 'file',
                    'label' => 'Upload File',
                    'desc' => 'Upload the specification or manual PDF.',
                    'return' => 'id',
                ],
                [
                    'id' => 'related_product',
                    'type' => 'post_select',
                    'label' => 'Related Product',
                    'post_type' => 'product',
                    'multiple' => true,
                    'desc' => 'Select the product(s) this download belongs to (Hold Ctrl/Cmd to select multiple).',
                ],
            ]
        ]
    ];

    // Initialize Download Post Meta
    new WP_Rapid_Fields_Pro($download_meta_config, $download_meta_tabs);

    // Add Theme Options to Admin Bar
    add_action('admin_bar_menu', 'taiyuetu_admin_bar_theme_options', 999);
    function taiyuetu_admin_bar_theme_options($wp_admin_bar)
    {
        if (!current_user_can('manage_options')) {
            return;
        }

        $wp_admin_bar->add_node([
            'id' => 'tqb_options',
            'title' => 'Theme Options',
            'href' => admin_url('admin.php?page=tqb_options'),
        ]);
    }

    /**
     * Bidirectional Sync for Product and Download
     * When you link a Download to a Product, the Product is automatically added to the Download's list.
     */
    add_action('save_post', 'taiyuetu_sync_relationship_meta', 20, 2);
    function taiyuetu_sync_relationship_meta($post_id, $post)
    {
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE)
            return;
        if ($post->post_status === 'auto-draft')
            return;

        $post_type = $post->post_type;
        $meta_key = '';
        $other_meta_key = '';

        if ($post_type === 'product') {
            $meta_key = 'pdf_download';
            $other_meta_key = 'related_product';
        }
        elseif ($post_type === 'download') {
            $meta_key = 'related_product';
            $other_meta_key = 'pdf_download';
        }
        else {
            return;
        }

        // We use a static variable to prevent infinite loops if we were using wp_update_post,
        // although update_post_meta doesn't trigger save_post.
        static $is_syncing = false;
        if ($is_syncing)
            return;
        $is_syncing = true;

        // Get new values from POST
        $new_values = isset($_POST[$meta_key]) ? (array)$_POST[$meta_key] : [];
        $new_values = array_map('intval', array_filter($new_values));

        // Get old values from DB (since we are at priority 20, DB might have been updated by WRF already)
        // Wait, if we are at priority 20, WRF (at 10) already updated the meta.
        // We need the "previous" state to know what was removed.
        // A better approach at priority 21 is to compare what is in the DB now with what SHOULD be in the linked posts.

        // Let's use priority 5 to get the OLD values first, then priority 20 to do the sync.
        // Or simpler: Get all posts that reference this one currently.

        $already_linked = get_posts([
            'post_type' => ($post_type === 'product' ? 'download' : 'product'),
            'posts_per_page' => -1,
            'meta_query' => [
                [
                    'key' => $other_meta_key,
                    'value' => '"' . $post_id . '"', // Serialized IDs are stored as strings in "i:123;" or similar
                    'compare' => 'LIKE',
                ]
            ],
            'fields' => 'ids',
            'suppress_filters' => true
        ]);

        // Items that should be linked
        foreach ($new_values as $target_id) {
            $list = get_post_meta($target_id, $other_meta_key, true);
            if (!is_array($list))
                $list = $list ? [$list] : [];
            $list = array_map('intval', $list);

            if (!in_array($post_id, $list)) {
                $list[] = $post_id;
                update_post_meta($target_id, $other_meta_key, array_values(array_unique($list)));
            }
        }

        // Items that were linked but are no longer in new_values
        $to_remove = array_diff($already_linked, $new_values);
        foreach ($to_remove as $target_id) {
            $list = get_post_meta($target_id, $other_meta_key, true);
            if (!is_array($list))
                $list = $list ? [$list] : [];
            $list = array_map('intval', $list);

            $key = array_search($post_id, $list);
            if ($key !== false) {
                unset($list[$key]);
                update_post_meta($target_id, $other_meta_key, array_values($list));
            }
        }

        $is_syncing = false;
    }
}
