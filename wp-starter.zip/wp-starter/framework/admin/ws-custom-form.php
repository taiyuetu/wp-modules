<?php
/**
 * BVD Dynamic AJAX Form (Advanced Theme-Integrated Version)
 * Description: Features AJAX, Custom DB Table, Admin Row Actions with View Modal, Honeypot, CAPTCHA, and Live JS Validation.
 * Version: 1.5
 */

if (!defined('ABSPATH'))
    exit;

// Ensure PHP sessions are available for CAPTCHA
add_action('init', function () {
    if (!session_id() && !headers_sent()) {
        session_start();
    }
});

/**
 * CAPTCHA Generator — returns a random math challenge via AJAX
 */
add_action('wp_ajax_bvd_generate_captcha', 'bvd_generate_captcha');
add_action('wp_ajax_nopriv_bvd_generate_captcha', 'bvd_generate_captcha');

function bvd_generate_captcha()
{
    if (!session_id() && !headers_sent()) {
        session_start();
    }

    $operators = ['+', '-'];
    $op = $operators[array_rand($operators)];

    if ($op === '+') {
        $a = rand(1, 30);
        $b = rand(1, 30);
        $answer = $a + $b;
    }
    else {
        $a = rand(10, 40);
        $b = rand(1, $a); // ensure positive result
        $answer = $a - $b;
    }

    $_SESSION['bvd_captcha_answer'] = $answer;

    wp_send_json_success([
        'expression' => "$a $op $b = ?",
    ]);
}

/**
 * 1. DATABASE SETUP
 */
function bvd_setup_custom_table()
{
    global $wpdb;
    $table_name = $wpdb->prefix . 'bvd_submissions';
    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE $table_name (
        id mediumint(9) NOT NULL AUTO_INCREMENT,
        time datetime DEFAULT '0000-00-00 00:00:00' NOT NULL,
        name varchar(100) NOT NULL,
        email varchar(100) NOT NULL,
        company varchar(100) NOT NULL,
        application varchar(50) DEFAULT '' NOT NULL,
        message text NOT NULL,
        status varchar(20) DEFAULT 'pending' NOT NULL,
        PRIMARY KEY  (id)
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
    update_option('bvd_db_version', '1.4');
}

add_action('after_switch_theme', 'bvd_setup_custom_table');
add_action('admin_init', function () {
    if (get_option('bvd_db_version') !== '1.4') {
        bvd_setup_custom_table();
    }
});

/**
 * 2. THE SHORTCODE [bvd_form wrap_class="your-class"]
 */
add_shortcode('bvd_form', 'bvd_render_cta_form');
function bvd_render_cta_form($atts)
{
    $options = shortcode_atts(array(
        'wrap_class' => 'cta-form-wrap',
    ), $atts);

    ob_start(); ?>
    <div class="<?php echo esc_attr($options['wrap_class']); ?>" id="bvd-form-container">
        <form class="cta-form" id="bvdContactForm" novalidate>
            <?php wp_nonce_field('bvd_form_action', 'bvd_form_nonce'); ?>
            
            <div style="display:none !important;">
                <input type="text" name="bvd_hp_field" value="" tabindex="-1" autocomplete="off">
            </div>

            <div class="form-group">
                <label for="name" class="form-label">Full Name *</label>
                <input type="text" id="name" name="name" class="form-input bvd-validate" data-rules="required" required>
                <span class="bvd-error-msg" style="color:red; font-size:12px; display:none;"></span>
            </div>
            
            <div class="form-group">
                <label for="email" class="form-label">Email Address *</label>
                <input type="email" id="email" name="email" class="form-input bvd-validate" data-rules="required|email" required>
                <span class="bvd-error-msg" style="color:red; font-size:12px; display:none;"></span>
            </div>
            
            <div class="form-group">
                <label for="company" class="form-label">Company Name *</label>
                <input type="text" id="company" name="company" class="form-input bvd-validate" data-rules="required" required>
                <span class="bvd-error-msg" style="color:red; font-size:12px; display:none;"></span>
            </div>
            
            <div class="form-group">
                <label for="application" class="form-label">Application Type</label>
                <select id="application" name="application" class="form-input">
                    <option value="">Select application</option>
                    <option value="passenger">Passenger Vehicles</option>
                    <option value="commercial">Commercial Vehicles</option>
                    <option value="offhighway">Off-Highway & Agriculture</option>
                    <option value="electric">Electric & Hybrid Vehicles</option>
                    <option value="other">Other</option>
                </select>
            </div>
            
            <div class="form-group">
                <label for="message" class="form-label">Project Details</label>
                <textarea id="message" name="message" class="form-input form-textarea" rows="4"></textarea>
            </div>

            <div class="form-group bvd-captcha-group">
                <label class="form-label">Verification Code *</label>
                <div class="bvd-captcha-row">
                    <canvas id="bvdCaptchaCanvas" width="180" height="50"></canvas>
                    <button type="button" id="bvdRefreshCaptcha" class="bvd-captcha-refresh" title="Refresh code">
                        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <polyline points="23 4 23 10 17 10"></polyline>
                            <polyline points="1 20 1 14 7 14"></polyline>
                            <path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"></path>
                        </svg>
                    </button>
                </div>
                <input type="text" id="bvdCaptchaInput" name="bvd_captcha" class="form-input bvd-validate" data-rules="required" placeholder="Enter the answer" autocomplete="off" required style="margin-top:6px; max-width:180px;">
                <span class="bvd-error-msg" style="color:red; font-size:12px; display:none;"></span>
            </div>
            
            <button type="submit" class="btn btn-primary btn-full" id="bvdSubmitBtn">
                <span class="btn-text">Submit Request</span>
                <svg class="btn-icon" width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M7.5 15L12.5 10L7.5 5" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                </svg>
            </button>
            
            <div id="bvdFormFeedback" style="margin-top: 15px; display: none; padding: 15px; border-radius: 5px; font-weight: 500;"></div>
        </form>
    </div>

    <style>
        .bvd-success { background: #e6fffa; color: #234e52; border: 1px solid #81e6d9; }
        .bvd-error { background: #fff5f5; color: #742a2a; border: 1px solid #feb2b2; }
        input.invalid, textarea.invalid, select.invalid { border-color: red !important; }
        #bvdSubmitBtn:disabled { opacity: 0.7; cursor: not-allowed; }

        /* CAPTCHA Styles */
        .bvd-captcha-group { margin-bottom: 15px; }
        .bvd-captcha-row {
            display: flex;
            align-items: center;
            gap: 10px;
        }
        #bvdCaptchaCanvas {
            border: 1px solid #ccc;
            border-radius: 4px;
            background: #f0f4f8;
            cursor: default;
            user-select: none;
        }
        .bvd-captcha-refresh {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            width: 36px;
            height: 36px;
            border: 1px solid #ccc;
            border-radius: 4px;
            background: #fff;
            cursor: pointer;
            color: #555;
            transition: all 0.25s ease;
        }
        .bvd-captcha-refresh:hover {
            background: #0073aa;
            color: #fff;
            border-color: #0073aa;
        }
        .bvd-captcha-refresh.spinning svg {
            animation: bvd-spin 0.5s ease;
        }
        @keyframes bvd-spin {
            from { transform: rotate(0deg); }
            to   { transform: rotate(360deg); }
        }
    </style>

    <script>
    document.addEventListener('DOMContentLoaded', function() {
        const form = document.getElementById('bvdContactForm');
        if (!form) return;

        const feedback = document.getElementById('bvdFormFeedback');
        const submitBtn = document.getElementById('bvdSubmitBtn');
        const fields = form.querySelectorAll('.bvd-validate');
        const ajaxUrl = '<?php echo admin_url('admin-ajax.php'); ?>';

        /* ==================== CAPTCHA RENDERING ==================== */
        const captchaCanvas = document.getElementById('bvdCaptchaCanvas');
        const captchaCtx = captchaCanvas ? captchaCanvas.getContext('2d') : null;
        const refreshBtn = document.getElementById('bvdRefreshCaptcha');

        function drawCaptcha(expression) {
            if (!captchaCtx) return;
            const W = captchaCanvas.width;
            const H = captchaCanvas.height;

            // Background gradient
            const grad = captchaCtx.createLinearGradient(0, 0, W, H);
            grad.addColorStop(0, '#e8edf2');
            grad.addColorStop(1, '#dce3ed');
            captchaCtx.fillStyle = grad;
            captchaCtx.fillRect(0, 0, W, H);

            // Noise — random lines
            for (let i = 0; i < 5; i++) {
                captchaCtx.strokeStyle = 'rgba(' + rand(80,180) + ',' + rand(80,180) + ',' + rand(80,180) + ',0.4)';
                captchaCtx.lineWidth = 1;
                captchaCtx.beginPath();
                captchaCtx.moveTo(rand(0, W), rand(0, H));
                captchaCtx.lineTo(rand(0, W), rand(0, H));
                captchaCtx.stroke();
            }

            // Noise — random dots
            for (let i = 0; i < 40; i++) {
                captchaCtx.fillStyle = 'rgba(' + rand(80,180) + ',' + rand(80,180) + ',' + rand(80,180) + ',0.5)';
                captchaCtx.beginPath();
                captchaCtx.arc(rand(0, W), rand(0, H), rand(1, 2), 0, Math.PI * 2);
                captchaCtx.fill();
            }

            // Draw the expression text
            captchaCtx.font = 'bold 22px "Courier New", monospace';
            captchaCtx.textBaseline = 'middle';
            captchaCtx.textAlign = 'center';

            // Draw each character with slight random offset & rotation for anti-OCR
            const chars = expression.split('');
            const startX = (W - chars.length * 14) / 2 + 7;
            chars.forEach(function(ch, i) {
                captchaCtx.save();
                captchaCtx.translate(startX + i * 14, H / 2 + rand(-3, 3));
                captchaCtx.rotate((rand(-12, 12) * Math.PI) / 180);
                captchaCtx.fillStyle = 'rgb(' + rand(20,80) + ',' + rand(20,80) + ',' + rand(80,150) + ')';
                captchaCtx.fillText(ch, 0, 0);
                captchaCtx.restore();
            });
        }

        function rand(min, max) {
            return Math.floor(Math.random() * (max - min + 1)) + min;
        }

        function loadCaptcha() {
            if (refreshBtn) {
                refreshBtn.classList.add('spinning');
                setTimeout(function(){ refreshBtn.classList.remove('spinning'); }, 500);
            }

            const fd = new FormData();
            fd.append('action', 'bvd_generate_captcha');

            fetch(ajaxUrl, { method: 'POST', body: fd })
                .then(function(r){ return r.json(); })
                .then(function(data) {
                    if (data.success) {
                        drawCaptcha(data.data.expression);
                    }
                });

            // Clear old input
            const captchaInput = document.getElementById('bvdCaptchaInput');
            if (captchaInput) captchaInput.value = '';
        }

        // Initial load
        loadCaptcha();

        // Refresh button
        if (refreshBtn) {
            refreshBtn.addEventListener('click', loadCaptcha);
        }

        /* ==================== VALIDATION ==================== */
        const validateField = (field) => {
            const rules = field.getAttribute('data-rules').split('|');
            const val = field.value.trim();
            const errorSpan = field.nextElementSibling;
            let isValid = true;
            let message = "";

            if (rules.includes('required') && !val) {
                isValid = false;
                message = "This field is required.";
            } else if (rules.includes('email') && val && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(val)) {
                isValid = false;
                message = "Please enter a valid email.";
            }

            if (!isValid) {
                field.classList.add('invalid');
                errorSpan.innerText = message;
                errorSpan.style.display = 'block';
            } else {
                field.classList.remove('invalid');
                errorSpan.style.display = 'none';
            }
            return isValid;
        };

        fields.forEach(field => {
            field.addEventListener('blur', () => validateField(field));
            field.addEventListener('input', () => { if(field.classList.contains('invalid')) validateField(field); });
        });

        /* ==================== FORM SUBMIT ==================== */
        form.addEventListener('submit', function(e) {
            e.preventDefault();
            let formIsValid = true;
            fields.forEach(f => { if(!validateField(f)) formIsValid = false; });
            if (!formIsValid) return;

            feedback.style.display = 'none';
            submitBtn.disabled = true;
            submitBtn.querySelector('.btn-text').innerText = 'Processing...';

            const formData = new FormData(form);
            formData.append('action', 'bvd_submit_form');

            fetch(ajaxUrl, {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                feedback.style.display = 'block';
                feedback.innerText = data.data.message;
                feedback.className = data.success ? 'bvd-success' : 'bvd-error';
                if (data.success) {
                    form.reset();
                }
                // Always refresh CAPTCHA after submit
                loadCaptcha();
            })
            .catch(() => {
                feedback.style.display = 'block';
                feedback.innerText = 'Server error.';
                feedback.className = 'bvd-error';
                loadCaptcha();
            })
            .finally(() => {
                submitBtn.disabled = false;
                submitBtn.querySelector('.btn-text').innerText = 'Submit Request';
            });
        });
    });
    </script>
    <?php
    return ob_get_clean();
}

/**
 * 3. AJAX HANDLER
 */
add_action('wp_ajax_bvd_submit_form', 'bvd_handle_form_submission');
add_action('wp_ajax_nopriv_bvd_submit_form', 'bvd_handle_form_submission');

function bvd_handle_form_submission()
{
    global $wpdb;

    if (!session_id() && !headers_sent()) {
        session_start();
    }

    check_ajax_referer('bvd_form_action', 'bvd_form_nonce');

    if (!empty($_POST['bvd_hp_field'])) {
        wp_send_json_error(['message' => 'Spam detected.']);
    }

    // Validate CAPTCHA
    $captcha_input = isset($_POST['bvd_captcha']) ? intval($_POST['bvd_captcha']) : null;
    $captcha_answer = isset($_SESSION['bvd_captcha_answer']) ? intval($_SESSION['bvd_captcha_answer']) : null;

    if ($captcha_answer === null || $captcha_input !== $captcha_answer) {
        wp_send_json_error(['message' => 'Incorrect verification code. Please try again.']);
    }

    // Clear used CAPTCHA so it can't be replayed
    unset($_SESSION['bvd_captcha_answer']);

    $name = sanitize_text_field($_POST['name']);
    $email = sanitize_email($_POST['email']);
    $company = sanitize_text_field($_POST['company']);
    $application = sanitize_text_field($_POST['application']);
    $message = sanitize_textarea_field($_POST['message']);

    if (empty($name) || empty($email) || !is_email($email)) {
        wp_send_json_error(['message' => 'Invalid data provided.']);
    }

    $table_name = $wpdb->prefix . 'bvd_submissions';
    $inserted = $wpdb->insert($table_name, array(
        'time' => current_time('mysql'),
        'name' => $name, 'email' => $email, 'company' => $company,
        'application' => $application, 'message' => $message, 'status' => 'pending'
    ));

    if ($inserted) {
        wp_mail(get_option('admin_email'), 'New Request from ' . $name, "Details:\nName: $name\nEmail: $email\nCompany: $company\nMessage: $message");
        wp_send_json_success(['message' => 'Success! Your message has been sent.']);
    }
    else {
        wp_send_json_error(['message' => 'Database error.']);
    }
}

/**
 * 4. ADMIN MENU & VIEW LOGIC
 */
add_action('admin_menu', 'bvd_register_admin_page');
function bvd_register_admin_page()
{
    add_menu_page('BVD Submissions', 'BVD Submissions', 'manage_options', 'bvd-submissions', 'bvd_render_admin_page', 'dashicons-database-export', 30);
}

function bvd_render_admin_page()
{
    global $wpdb;
    $table_name = $wpdb->prefix . 'bvd_submissions';

    // Handle Row Actions
    if (isset($_GET['action']) && isset($_GET['id']) && check_admin_referer('bvd_row_action')) {
        $id = intval($_GET['id']);
        if ($_GET['action'] === 'confirm') {
            $wpdb->update($table_name, ['status' => 'confirmed'], ['id' => $id]);
        }
        elseif ($_GET['action'] === 'delete') {
            $wpdb->delete($table_name, ['id' => $id]);
        }
        echo '<script>window.location.href="' . admin_url('admin.php?page=bvd-submissions') . '";</script>';
        exit;
    }

    if (isset($_POST['bvd_delete_all']) && check_admin_referer('bvd_admin_action')) {
        $wpdb->query("TRUNCATE TABLE $table_name");
        echo '<div class="updated"><p>All records cleared.</p></div>';
    }

    $results = $wpdb->get_results("SELECT * FROM $table_name ORDER BY time DESC");
?>
    <div class="wrap">
        <h1>BVD Form Submissions</h1>
        
        <table class="wp-list-table widefat fixed striped">
            <thead>
                <tr>
                    <th style="width:150px;">Date</th>
                    <th>Name</th>
                    <th style="width:100px;">Status</th>
                    <th>Email</th>
                    <th>Details (Preview)</th>
                    <th style="text-align:right; width:180px;">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($results):
        foreach ($results as $row):
            $confirm_url = wp_nonce_url(admin_url("admin.php?page=bvd-submissions&action=confirm&id=$row->id"), 'bvd_row_action');
            $delete_url = wp_nonce_url(admin_url("admin.php?page=bvd-submissions&action=delete&id=$row->id"), 'bvd_row_action');
?>
                    <tr id="row-<?php echo $row->id; ?>">
                        <td><?php echo $row->time; ?></td>
                        <td><strong><?php echo esc_html($row->name); ?></strong></td>
                        <td><span style="padding:2px 6px; border-radius:4px; font-size:10px; background:<?php echo $row->status === 'confirmed' ? '#46b450' : '#ffb900'; ?>; color:#fff;"><?php echo strtoupper($row->status); ?></span></td>
                        <td><?php echo esc_html($row->email); ?></td>
                        <td>
                            <div style="max-height: 1.5em; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">
                                <?php echo esc_html($row->message); ?>
                            </div>
                        </td>
                        <td style="text-align:right;">
                            <button type="button" class="button button-small bvd-view-btn" 
                                data-name="<?php echo esc_attr($row->name); ?>"
                                data-email="<?php echo esc_attr($row->email); ?>"
                                data-company="<?php echo esc_attr($row->company); ?>"
                                data-app="<?php echo esc_attr($row->application); ?>"
                                data-time="<?php echo esc_attr($row->time); ?>"
                                data-msg="<?php echo esc_attr($row->message); ?>">View</button>
                            
                            <?php if ($row->status !== 'confirmed'): ?>
                                <a href="<?php echo $confirm_url; ?>" class="button button-small">Confirm</a>
                            <?php
            endif; ?>
                            <a href="<?php echo $delete_url; ?>" class="button button-small" style="color:#a00;" onclick="return confirm('Delete permanently?')">Delete</a>
                        </td>
                    </tr>
                <?php
        endforeach;
    else: ?>
                    <tr><td colspan="6">No entries.</td></tr>
                <?php
    endif; ?>
            </tbody>
        </table>

        <form method="post" style="margin-top:20px;">
            <?php wp_nonce_field('bvd_admin_action'); ?>
            <input type="submit" name="bvd_delete_all" class="button button-link-delete" value="Truncate Table" onclick="return confirm('Clear ALL?');">
        </form>
    </div>

    <!-- Admin Modal for Viewing Single Submission -->
    <div id="bvdModal" style="display:none; position:fixed; z-index:99999; left:0; top:0; width:100%; height:100%; background:rgba(0,0,0,0.7);">
        <div style="background:#fff; margin:5% auto; padding:20px; width:60%; max-width:800px; border-radius:8px; position:relative; max-height:80vh; overflow-y:auto;">
            <span id="bvdCloseModal" style="position:absolute; right:20px; top:10px; font-size:28px; cursor:pointer;">&times;</span>
            <h2 id="modalName" style="margin-top:0;"></h2>
            <hr>
            <div id="modalContent" style="line-height:1.6;">
                <p><strong>Date:</strong> <span id="mDate"></span></p>
                <p><strong>Email:</strong> <span id="mEmail"></span></p>
                <p><strong>Company:</strong> <span id="mCompany"></span></p>
                <p><strong>Application:</strong> <span id="mApp"></span></p>
                <div style="background:#f9f9f9; padding:15px; border-left:4px solid #0073aa; margin-top:15px;">
                    <strong>Message:</strong><br>
                    <div id="mMsg" style="white-space: pre-wrap;"></div>
                </div>
            </div>
        </div>
    </div>

    <script>
    jQuery(document).ready(function($) {
        $('.bvd-view-btn').on('click', function() {
            const data = $(this).data();
            $('#modalName').text('Submission from ' + data.name);
            $('#mDate').text(data.time);
            $('#mEmail').text(data.email);
            $('#mCompany').text(data.company);
            $('#mApp').text(data.app || 'N/A');
            $('#mMsg').text(data.msg);
            $('#bvdModal').fadeIn(200);
        });

        $('#bvdCloseModal, #bvdModal').on('click', function(e) {
            if (e.target !== this && e.target.id !== 'bvdCloseModal') return;
            $('#bvdModal').fadeOut(200);
        });
    });
    </script>
    <?php
}