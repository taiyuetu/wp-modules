<?php
/**
 * Trust Section block render template.
 *
 * @param array    $attributes Block attributes.
 * @param string   $content    Block inner content (unused).
 * @param WP_Block $block      Block instance.
 */

$section_label = isset($attributes['sectionLabel']) ? $attributes['sectionLabel'] : '';
$logos = isset($attributes['logos']) ? $attributes['logos'] : [];
$testimonials = isset($attributes['testimonials']) ? $attributes['testimonials'] : [];
?>
<section <?php echo get_block_wrapper_attributes(['class' => 'trust', 'id' => 'trust']); ?>>
	<div class="container">

		<?php if ($section_label): ?>
		<div class="trust-header">
			<p class="section-label"><?php echo wp_kses_post($section_label); ?></p>
		</div>
		<?php
endif; ?>

		<?php if (!empty($logos)): ?>
		<div class="trust-logos">
			<?php foreach ($logos as $logo): ?>
			<div class="trust-logo-item">
				<?php if (!empty($logo['imageUrl'])): ?>
					<img
						src="<?php echo esc_url($logo['imageUrl']); ?>"
						alt="<?php echo esc_attr(wp_strip_all_tags($logo['text'] ?? '')); ?>"
						class="trust-logo-img"
					/>
				<?php
		else: ?>
					<div class="trust-logo-placeholder">
						<?php echo wp_kses_post($logo['text'] ?? ''); ?>
					</div>
				<?php
		endif; ?>
			</div>
			<?php
	endforeach; ?>
		</div>
		<?php
endif; ?>

		<?php if (!empty($testimonials)): ?>
		<div class="trust-testimonials">
			<?php foreach ($testimonials as $testimonial): ?>
			<div class="testimonial-card">
				<div class="testimonial-quote">
					<?php echo wp_kses_post($testimonial['quote'] ?? ''); ?>
				</div>
				<div class="testimonial-author">
					<div class="author-name"><?php echo wp_kses_post($testimonial['authorName'] ?? ''); ?></div>
					<div class="author-title"><?php echo wp_kses_post($testimonial['authorTitle'] ?? ''); ?></div>
				</div>
			</div>
			<?php
	endforeach; ?>
		</div>
		<?php
endif; ?>

	</div>
</section>