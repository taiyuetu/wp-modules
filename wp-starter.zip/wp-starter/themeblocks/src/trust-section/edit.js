import { __ } from '@wordpress/i18n';
import {
	useBlockProps,
	RichText,
	MediaUpload,
	MediaUploadCheck,
} from '@wordpress/block-editor';
import { Button, Icon } from '@wordpress/components';
import { plus, trash } from '@wordpress/icons';
import './editor.scss';

export default function Edit({ attributes, setAttributes }) {
	const { sectionLabel, logos, testimonials } = attributes;
	const blockProps = useBlockProps({ className: 'trust' });

	// --- Logo helpers ---
	const updateLogo = (index, field, value) => {
		const updated = logos.map((logo, i) =>
			i === index ? { ...logo, [field]: value } : logo
		);
		setAttributes({ logos: updated });
	};

	const addLogo = () => {
		const newId = logos.length ? Math.max(...logos.map(l => l.id)) + 1 : 1;
		setAttributes({
			logos: [
				...logos,
				{ id: newId, text: __('New Logo', 'trust-section'), imageUrl: '', imageId: 0 },
			],
		});
	};

	const removeLogo = (index) => {
		setAttributes({ logos: logos.filter((_, i) => i !== index) });
	};

	// --- Testimonial helpers ---
	const updateTestimonial = (index, field, value) => {
		const updated = testimonials.map((t, i) =>
			i === index ? { ...t, [field]: value } : t
		);
		setAttributes({ testimonials: updated });
	};

	const addTestimonial = () => {
		const newId = testimonials.length
			? Math.max(...testimonials.map(t => t.id)) + 1
			: 1;
		setAttributes({
			testimonials: [
				...testimonials,
				{
					id: newId,
					quote: __('Your testimonial quote here.', 'trust-section'),
					authorName: __('Author Name', 'trust-section'),
					authorTitle: __('Author Title', 'trust-section'),
				},
			],
		});
	};

	const removeTestimonial = (index) => {
		setAttributes({
			testimonials: testimonials.filter((_, i) => i !== index),
		});
	};

	return (
		<section {...blockProps} id="trust">
			<div className="container">

				{/* Header */}
				<div className="trust-header">
					<RichText
						tagName="p"
						className="section-label"
						value={sectionLabel}
						onChange={(value) => setAttributes({ sectionLabel: value })}
						placeholder={__('Section label…', 'trust-section')}
					/>
				</div>

				{/* Logos */}
				<div className="trust-logos">
					{logos.map((logo, index) => (
						<div className="trust-logo-item is-editing" key={logo.id}>
							<button
								className="trust-remove-btn"
								onClick={() => removeLogo(index)}
								aria-label={__('Remove logo', 'trust-section')}
							>
								<Icon icon={trash} />
							</button>

							<MediaUploadCheck>
								<MediaUpload
									onSelect={(media) => {
										const updated = logos.map((l, i) =>
											i === index
												? { ...l, imageUrl: media.url, imageId: media.id }
												: l
										);
										setAttributes({ logos: updated });
									}}
									allowedTypes={['image']}
									value={logo.imageId}
									render={({ open }) => (
										<div className="trust-logo-media-wrap" onClick={open}>
											{logo.imageUrl ? (
												<img
													src={logo.imageUrl}
													alt={logo.text}
													className="trust-logo-img"
												/>
											) : (
												<div className="trust-logo-placeholder">
													<RichText
														tagName="span"
														value={logo.text}
														onChange={(value) =>
															updateLogo(index, 'text', value)
														}
														placeholder={__('Logo text…', 'trust-section')}
														onClick={(e) => e.stopPropagation()}
													/>
													<span className="trust-logo-upload-hint">
														{__('Click to upload image', 'trust-section')}
													</span>
												</div>
											)}
										</div>
									)}
								/>
							</MediaUploadCheck>

							{logo.imageUrl && (
								<Button
									isDestructive
									variant="link"
									className="trust-logo-remove-img"
									onClick={() => {
										const updated = logos.map((l, i) =>
											i === index
												? { ...l, imageUrl: '', imageId: 0 }
												: l
										);
										setAttributes({ logos: updated });
									}}
								>
									{__('Remove image', 'trust-section')}
								</Button>
							)}
						</div>
					))}

					<button className="trust-add-btn" onClick={addLogo}>
						<Icon icon={plus} />
						{__('Add Logo', 'trust-section')}
					</button>
				</div>

				{/* Testimonials */}
				<div className="trust-testimonials">
					{testimonials.map((testimonial, index) => (
						<div className="testimonial-card" key={testimonial.id}>
							<button
								className="trust-remove-btn"
								onClick={() => removeTestimonial(index)}
								aria-label={__('Remove testimonial', 'trust-section')}
							>
								<Icon icon={trash} />
							</button>

							<div className="testimonial-quote">
								<RichText
									tagName="span"
									value={testimonial.quote}
									onChange={(value) =>
										updateTestimonial(index, 'quote', value)
									}
									placeholder={__('Enter quote…', 'trust-section')}
								/>
							</div>

							<div className="testimonial-author">
								<RichText
									tagName="div"
									className="author-name"
									value={testimonial.authorName}
									onChange={(value) =>
										updateTestimonial(index, 'authorName', value)
									}
									placeholder={__('Author name…', 'trust-section')}
								/>
								<RichText
									tagName="div"
									className="author-title"
									value={testimonial.authorTitle}
									onChange={(value) =>
										updateTestimonial(index, 'authorTitle', value)
									}
									placeholder={__('Author title…', 'trust-section')}
								/>
							</div>
						</div>
					))}

					<button className="trust-add-btn" onClick={addTestimonial}>
						<Icon icon={plus} />
						{__('Add Testimonial', 'trust-section')}
					</button>
				</div>

			</div>
		</section>
	);
}