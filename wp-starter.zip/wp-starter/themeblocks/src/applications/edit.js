import { __ } from '@wordpress/i18n';
import { useBlockProps } from '@wordpress/block-editor';
import { RichText } from '@wordpress/block-editor';
import { Button, SelectControl } from '@wordpress/components';

/**
 * SVG icons keyed by iconType value.
 */
const ICONS = {
	passenger: (
		<svg width="40" height="40" viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
			<rect x="4" y="20" width="32" height="12" rx="2" stroke="currentColor" strokeWidth="2" />
			<circle cx="12" cy="32" r="4" stroke="currentColor" strokeWidth="2" />
			<circle cx="28" cy="32" r="4" stroke="currentColor" strokeWidth="2" />
			<path d="M4 20L8 12H20L24 20" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
		</svg>
	),
	commercial: (
		<svg width="40" height="40" viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
			<rect x="2" y="16" width="36" height="16" rx="2" stroke="currentColor" strokeWidth="2" />
			<circle cx="10" cy="32" r="4" stroke="currentColor" strokeWidth="2" />
			<circle cx="30" cy="32" r="4" stroke="currentColor" strokeWidth="2" />
			<path d="M2 16L6 8H16L20 16" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
			<rect x="24" y="10" width="8" height="6" stroke="currentColor" strokeWidth="2" />
		</svg>
	),
	offhighway: (
		<svg width="40" height="40" viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
			<path d="M8 28L12 20H20L16 28H8Z" stroke="currentColor" strokeWidth="2" strokeLinejoin="round" />
			<circle cx="12" cy="28" r="3" stroke="currentColor" strokeWidth="2" />
			<path d="M20 28L24 20H32L28 28H20Z" stroke="currentColor" strokeWidth="2" strokeLinejoin="round" />
			<circle cx="24" cy="28" r="3" stroke="currentColor" strokeWidth="2" />
			<path d="M16 12L20 8L24 12" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
		</svg>
	),
	electric: (
		<svg width="40" height="40" viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
			<circle cx="20" cy="20" r="12" stroke="currentColor" strokeWidth="2" />
			<path d="M20 8V12M20 28V32M8 20H12M28 20H32" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
			<circle cx="20" cy="20" r="4" fill="currentColor" />
			<path d="M14 14L16 16M26 14L24 16M14 26L16 24M26 26L24 24" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
		</svg>
	),
};

const ICON_OPTIONS = [
	{ label: __( 'Passenger Vehicles', 'applications-block' ), value: 'passenger' },
	{ label: __( 'Commercial Vehicles', 'applications-block' ), value: 'commercial' },
	{ label: __( 'Off-Highway & Agriculture', 'applications-block' ), value: 'offhighway' },
	{ label: __( 'Electric & Hybrid', 'applications-block' ), value: 'electric' },
];

/**
 * Individual card editor component.
 */
function ApplicationCard( { card, index, onChange, onRemove, canRemove } ) {
	const updateCard = ( key, value ) => {
		onChange( index, { ...card, [ key ]: value } );
	};

	return (
		<div className="application-card application-card--editing">
			<div className="application-card__controls">
				<div className="application-icon-wrap">
					{ ICONS[ card.iconType ] || ICONS.passenger }
				</div>

				<div className="application-card__icon-select">
					<SelectControl
						label={ __( 'Icon', 'applications-block' ) }
						value={ card.iconType }
						options={ ICON_OPTIONS }
						onChange={ ( value ) => updateCard( 'iconType', value ) }
						__nextHasNoMarginBottom
					/>
				</div>

				{ canRemove && (
					<Button
						className="application-card__remove"
						isDestructive
						isSmall
						onClick={ () => onRemove( index ) }
						icon="trash"
						label={ __( 'Remove card', 'applications-block' ) }
					/>
				) }
			</div>

			<RichText
				tagName="h3"
				className="application-title"
				value={ card.title }
				onChange={ ( value ) => updateCard( 'title', value ) }
				placeholder={ __( 'Card title…', 'applications-block' ) }
				allowedFormats={ [] }
			/>

			<RichText
				tagName="p"
				className="application-description"
				value={ card.description }
				onChange={ ( value ) => updateCard( 'description', value ) }
				placeholder={ __( 'Card description…', 'applications-block' ) }
				allowedFormats={ [ 'core/bold', 'core/italic' ] }
			/>
		</div>
	);
}

/**
 * Block Edit component — full WYSIWYG, no sidebar fields.
 */
export default function Edit( { attributes, setAttributes } ) {
	const { sectionLabel, sectionTitle, cards } = attributes;
	const blockProps = useBlockProps( { className: 'applications' } );

	// Update a single card by index
	const updateCard = ( index, updatedCard ) => {
		const newCards = cards.map( ( card, i ) => ( i === index ? updatedCard : card ) );
		setAttributes( { cards: newCards } );
	};

	// Remove a card by index
	const removeCard = ( index ) => {
		const newCards = cards.filter( ( _, i ) => i !== index );
		setAttributes( { cards: newCards } );
	};

	// Add a new blank card
	const addCard = () => {
		const newCard = {
			id: Date.now(),
			title: __( 'New Application', 'applications-block' ),
			description: __( 'Describe this application area here.', 'applications-block' ),
			iconType: 'passenger',
		};
		setAttributes( { cards: [ ...cards, newCard ] } );
	};

	return (
		<section { ...blockProps }>
			<div className="container">
				<div className="section-header">
					<RichText
						tagName="p"
						className="section-label"
						value={ sectionLabel }
						onChange={ ( value ) => setAttributes( { sectionLabel: value } ) }
						placeholder={ __( 'Section label…', 'applications-block' ) }
						allowedFormats={ [] }
					/>
					<RichText
						tagName="h2"
						className="section-title"
						value={ sectionTitle }
						onChange={ ( value ) => setAttributes( { sectionTitle: value } ) }
						placeholder={ __( 'Section title…', 'applications-block' ) }
						allowedFormats={ [ 'core/bold', 'core/italic' ] }
					/>
				</div>

				<div className="applications-grid">
					{ cards.map( ( card, index ) => (
						<ApplicationCard
							key={ card.id || index }
							card={ card }
							index={ index }
							onChange={ updateCard }
							onRemove={ removeCard }
							canRemove={ cards.length > 1 }
						/>
					) ) }
				</div>

				<div className="applications-block__add-card">
					<Button
						variant="secondary"
						onClick={ addCard }
						icon="plus-alt2"
					>
						{ __( 'Add Card', 'applications-block' ) }
					</Button>
				</div>
			</div>
		</section>
	);
}
