<?php
/**
 * Applications Section Block - render.php
 *
 * @param array    $attributes Block attributes.
 * @param string   $content    Block default content.
 * @param WP_Block $block      Block instance.
 */

$section_label = isset($attributes['sectionLabel']) ? esc_html($attributes['sectionLabel']) : 'Application Engineering';
$section_title = isset($attributes['sectionTitle']) ? esc_html($attributes['sectionTitle']) : 'Tailored Solutions For Every Industry';
$cards = isset($attributes['cards']) ? $attributes['cards'] : array();

if (!function_exists('applications_block_get_icon')) {	/**
	 * Returns inline SVG markup for each card icon type.
	 */	function applications_block_get_icon(string $icon_type): string
	{
		$icons = array(
			'passenger' => '<svg class="application-icon" width="40" height="40" viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
			<rect x="4" y="20" width="32" height="12" rx="2" stroke="currentColor" stroke-width="2"/>
			<circle cx="12" cy="32" r="4" stroke="currentColor" stroke-width="2"/>
			<circle cx="28" cy="32" r="4" stroke="currentColor" stroke-width="2"/>
			<path d="M4 20L8 12H20L24 20" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
		</svg>',

			'commercial' => '<svg class="application-icon" width="40" height="40" viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
			<rect x="2" y="16" width="36" height="16" rx="2" stroke="currentColor" stroke-width="2"/>
			<circle cx="10" cy="32" r="4" stroke="currentColor" stroke-width="2"/>
			<circle cx="30" cy="32" r="4" stroke="currentColor" stroke-width="2"/>
			<path d="M2 16L6 8H16L20 16" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
			<rect x="24" y="10" width="8" height="6" stroke="currentColor" stroke-width="2"/>
		</svg>',

			'offhighway' => '<svg class="application-icon" width="40" height="40" viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
			<path d="M8 28L12 20H20L16 28H8Z" stroke="currentColor" stroke-width="2" stroke-linejoin="round"/>
			<circle cx="12" cy="28" r="3" stroke="currentColor" stroke-width="2"/>
			<path d="M20 28L24 20H32L28 28H20Z" stroke="currentColor" stroke-width="2" stroke-linejoin="round"/>
			<circle cx="24" cy="28" r="3" stroke="currentColor" stroke-width="2"/>
			<path d="M16 12L20 8L24 12" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
		</svg>',

			'electric' => '<svg class="application-icon" width="40" height="40" viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
			<circle cx="20" cy="20" r="12" stroke="currentColor" stroke-width="2"/>
			<path d="M20 8V12M20 28V32M8 20H12M28 20H32" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
			<circle cx="20" cy="20" r="4" fill="currentColor"/>
			<path d="M14 14L16 16M26 14L24 16M14 26L16 24M26 26L24 24" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
		</svg>',
		);

		return isset($icons[$icon_type]) ? $icons[$icon_type] : $icons['passenger'];	}
}

?>

<section class="applications" <?php echo get_block_wrapper_attributes(); ?>>
	<div class="container">
		<div class="section-header">
			<p class="section-label"><?php echo $section_label; ?></p>
			<h2 class="section-title"><?php echo $section_title; ?></h2>
		</div>

		<?php if (!empty($cards)): ?>
			<div class="applications-grid">
				<?php foreach ($cards as $card):
		$card_title = isset($card['title']) ? esc_html($card['title']) : '';
		$card_description = isset($card['description']) ? esc_html($card['description']) : '';
		$icon_type = isset($card['iconType']) ? sanitize_key($card['iconType']) : 'passenger';
?>
					<div class="application-card">
						<div class="application-icon-wrap">
							<?php echo applications_block_get_icon($icon_type); ?>
						</div>
						<h3 class="application-title"><?php echo $card_title; ?></h3>
						<p class="application-description"><?php echo $card_description; ?></p>
					</div>
				<?php
	endforeach; ?>
			</div>
		<?php
endif; ?>
	</div>
</section>
