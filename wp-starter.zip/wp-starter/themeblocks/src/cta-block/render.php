<?php
/**
 * CTA Block — Front-end Render
 *
 * @param array    $attributes Block attributes.
 * @param string   $content    Inner block content (unused).
 * @param WP_Block $block      Block instance.
 *
 * @package cta-block
 */

defined( 'ABSPATH' ) || exit;

$title         = isset( $attributes['title'] )        ? $attributes['title']        : '';
$description   = isset( $attributes['description'] )  ? $attributes['description']  : '';
$features      = isset( $attributes['features'] )     ? $attributes['features']     : [];
$form_shortcode = isset( $attributes['formShortcode'] ) ? $attributes['formShortcode'] : '';
$anchor_id     = isset( $attributes['anchorId'] )     ? $attributes['anchorId']     : 'contact';

$wrapper_attributes = get_block_wrapper_attributes( [
	'class' => 'cta',
	'id'    => esc_attr( $anchor_id ),
] );
?>

<section <?php echo $wrapper_attributes; ?>>
	<div class="container">
		<div class="cta-content">

			<div class="cta-text">

				<?php if ( $title ) : ?>
					<h2 class="cta-title"><?php echo wp_kses_post( $title ); ?></h2>
				<?php endif; ?>

				<?php if ( $description ) : ?>
					<p class="cta-description"><?php echo wp_kses_post( $description ); ?></p>
				<?php endif; ?>

				<?php if ( ! empty( $features ) ) : ?>
					<div class="cta-features">
						<?php foreach ( $features as $feature ) :
							if ( empty( $feature['text'] ) ) continue;
						?>
							<div class="cta-feature">
								<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" focusable="false">
									<path d="M20 6L9 17L4 12" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
								</svg>
								<span><?php echo wp_kses_post( $feature['text'] ); ?></span>
							</div>
						<?php endforeach; ?>
					</div>
				<?php endif; ?>

			</div><!-- .cta-text -->

			<?php if ( $form_shortcode ) : ?>
				<div class="cta-form">
					<?php echo do_shortcode( wp_kses_post( $form_shortcode ) ); ?>
				</div>
			<?php endif; ?>

		</div><!-- .cta-content -->
	</div><!-- .container -->
</section>
