<?php
/**
 * Why Choose Us Block — render.php
 *
 * @param array    $attributes Block attributes.
 * @param string   $content    Inner block content (unused).
 * @param WP_Block $block      Block instance.
 */

$section_label       = ! empty( $attributes['sectionLabel'] )       ? $attributes['sectionLabel']       : '';
$section_title       = ! empty( $attributes['sectionTitle'] )       ? $attributes['sectionTitle']       : '';
$section_description = ! empty( $attributes['sectionDescription'] ) ? $attributes['sectionDescription'] : '';
$items               = ! empty( $attributes['items'] )              ? $attributes['items']               : [];

// Gradient pairs for SVG placeholders (mirrors the editor).
$gradients = [
	[ 'from' => '#1D4E89', 'to' => '#2a5f9e' ],
	[ 'from' => '#2a5f9e', 'to' => '#1D4E89' ],
	[ 'from' => '#1D4E89', 'to' => '#2a5f9e' ],
	[ 'from' => '#2a5f9e', 'to' => '#1D4E89' ],
	[ 'from' => '#1D4E89', 'to' => '#2a5f9e' ],
];

$wrapper_attributes = get_block_wrapper_attributes( [ 'class' => 'why-choose-us' ] );
?>

<section <?php echo $wrapper_attributes; ?>>
	<div class="container">

		<!-- Section Header -->
		<div class="section-header">
			<?php if ( $section_label ) : ?>
				<p class="section-label"><?php echo wp_kses_post( $section_label ); ?></p>
			<?php endif; ?>

			<?php if ( $section_title ) : ?>
				<h2 class="section-title"><?php echo wp_kses_post( $section_title ); ?></h2>
			<?php endif; ?>

			<?php if ( $section_description ) : ?>
				<p class="section-description"><?php echo wp_kses_post( $section_description ); ?></p>
			<?php endif; ?>
		</div>

		<?php foreach ( $items as $index => $item ) :
			$is_reverse   = ( $index % 2 !== 0 );
			$item_class   = 'choice-item' . ( $is_reverse ? ' choice-item-reverse' : '' );
			$number       = isset( $item['number'] )      ? esc_html( $item['number'] )            : '';
			$title        = isset( $item['title'] )       ? wp_kses_post( $item['title'] )          : '';
			$description  = isset( $item['description'] ) ? wp_kses_post( $item['description'] )    : '';
			$highlights   = isset( $item['highlights'] )  ? (array) $item['highlights']             : [];
			$image_url    = isset( $item['imageUrl'] )    ? esc_url( $item['imageUrl'] )            : '';
			$image_alt    = isset( $item['imageAlt'] )    ? esc_attr( $item['imageAlt'] )           : esc_attr( $title );
			$gradient_idx = $index % count( $gradients );
			$grad         = $gradients[ $gradient_idx ];
			$grad_id      = 'wcu-grad-' . $index;
		?>
		<div class="<?php echo esc_attr( $item_class ); ?>">

			<!-- Content -->
			<div class="choice-content">
				<?php if ( $number ) : ?>
					<div class="choice-number"><?php echo esc_html( $number ); ?></div>
				<?php endif; ?>

				<?php if ( $title ) : ?>
					<h3 class="choice-title"><?php echo wp_kses_post( $title ); ?></h3>
				<?php endif; ?>

				<?php if ( $description ) : ?>
					<p class="choice-description"><?php echo wp_kses_post( $description ); ?></p>
				<?php endif; ?>

				<?php if ( ! empty( $highlights ) ) : ?>
					<ul class="choice-highlights">
						<?php foreach ( $highlights as $hl ) : ?>
							<li><?php echo wp_kses_post( $hl ); ?></li>
						<?php endforeach; ?>
					</ul>
				<?php endif; ?>
			</div>

			<!-- Image -->
			<div class="choice-image">
				<?php if ( $image_url ) : ?>
					<div class="choice-image-placeholder">
						<img
							src="<?php echo $image_url; ?>"
							alt="<?php echo $image_alt; ?>"
							loading="lazy"
							style="width:100%;height:100%;object-fit:cover;display:block;border-radius:8px;"
						/>
					</div>
				<?php else : ?>
					<div class="choice-image-placeholder">
						<svg width="100%" height="100%" viewBox="0 0 400 300" fill="none" xmlns="http://www.w3.org/2000/svg">
							<defs>
								<linearGradient id="<?php echo esc_attr( $grad_id ); ?>" x1="0" y1="0" x2="400" y2="300">
									<stop offset="0%"   stop-color="<?php echo esc_attr( $grad['from'] ); ?>" />
									<stop offset="100%" stop-color="<?php echo esc_attr( $grad['to'] ); ?>" />
								</linearGradient>
							</defs>
							<rect width="400" height="300" fill="url(#<?php echo esc_attr( $grad_id ); ?>)" />
							<circle cx="200" cy="150" r="80" stroke="#ffffff" stroke-width="3" opacity="0.3" />
							<circle cx="200" cy="150" r="60" stroke="#ffffff" stroke-width="3" opacity="0.5" />
							<circle cx="200" cy="150" r="40" stroke="#ffffff" stroke-width="3" opacity="0.7" />
							<circle cx="200" cy="150" r="20" fill="#ffffff" opacity="0.9" />
						</svg>
					</div>
				<?php endif; ?>
			</div>

		</div>
		<?php endforeach; ?>

	</div>
</section>
