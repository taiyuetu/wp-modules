import { __ } from '@wordpress/i18n';
import {
	RichText,
	MediaUpload,
	MediaUploadCheck,
	useBlockProps,
} from '@wordpress/block-editor';
import { Button } from '@wordpress/components';

export default function Edit({ attributes, setAttributes }) {
	const {
		sectionLabel,
		sectionTitle,
		valueDescription,
		imageUrl,
		imageAlt,
		features,
	} = attributes;

	const blockProps = useBlockProps({ className: 'value' });

	const updateFeature = (index, field, value) => {
		const updated = features.map((item, i) =>
			i === index ? { ...item, [field]: value } : item
		);
		setAttributes({ features: updated });
	};

	const addFeature = () => {
		const newNumber = String(features.length + 1).padStart(2, '0');
		setAttributes({
			features: [
				...features,
				{
					number: newNumber,
					title: __('New Feature', 'value-section'),
					description: __('Feature description goes here.', 'value-section'),
				},
			],
		});
	};

	const removeFeature = (index) => {
		setAttributes({
			features: features.filter((_, i) => i !== index),
		});
	};

	return (
		<section {...blockProps}>
			<div className="container">
				<div className="value-content">

					{ /* Image Column */}
					<div className="value-image">
						<MediaUploadCheck>
							<MediaUpload
								onSelect={(media) =>
									setAttributes({
										imageId: media.id,
										imageUrl: media.url,
										imageAlt: media.alt || '',
									})
								}
								allowedTypes={['image']}
								value={attributes.imageId}
								render={({ open }) => (
									<div className="value-image-wrapper">
										{imageUrl ? (
											<>
												<img src={imageUrl} alt={imageAlt} />
												<div className="value-image-controls">
													<Button
														variant="secondary"
														onClick={open}
														className="value-replace-btn"
													>
														{__('Replace Image', 'value-section')}
													</Button>
													<Button
														variant="secondary"
														isDestructive
														onClick={() =>
															setAttributes({
																imageId: 0,
																imageUrl: '',
																imageAlt: '',
															})
														}
														className="value-remove-btn"
													>
														{__('Remove', 'value-section')}
													</Button>
												</div>
											</>
										) : (
											<div className="value-image-placeholder">
												<div className="technical-diagram">
													<div className="diagram-layer"></div>
													<div className="diagram-layer"></div>
													<div className="diagram-layer"></div>
												</div>
												<Button
													variant="primary"
													onClick={open}
													className="value-upload-btn"
												>
													{__('Upload Image', 'value-section')}
												</Button>
											</div>
										)}
									</div>
								)}
							/>
						</MediaUploadCheck>
					</div>

					{ /* Text Column */}
					<div className="value-text">

						<RichText
							tagName="p"
							className="section-label"
							value={sectionLabel}
							onChange={(val) => setAttributes({ sectionLabel: val })}
							placeholder={__('Section label…', 'value-section')}
							allowedFormats={[]}
						/>

						<RichText
							tagName="h2"
							className="section-title"
							value={sectionTitle}
							onChange={(val) => setAttributes({ sectionTitle: val })}
							placeholder={__('Section title…', 'value-section')}
							allowedFormats={[]}
						/>

						<RichText
							tagName="p"
							className="value-description"
							value={valueDescription}
							onChange={(val) =>
								setAttributes({ valueDescription: val })
							}
							placeholder={__('Description…', 'value-section')}
							allowedFormats={['core/bold', 'core/italic']}
						/>

						<div className="value-features">
							{features.map((feature, index) => (
								<div className="value-feature-item" key={index}>
									<div className="value-feature-number-wrapper">
										<RichText
											tagName="div"
											className="value-feature-number"
											value={feature.number}
											onChange={(val) =>
												updateFeature(index, 'number', val)
											}
											placeholder="01"
											allowedFormats={[]}
										/>
									</div>
									<div className="value-feature-content">
										<RichText
											tagName="h4"
											value={feature.title}
											onChange={(val) =>
												updateFeature(index, 'title', val)
											}
											placeholder={__('Feature title…', 'value-section')}
											allowedFormats={[]}
										/>
										<RichText
											tagName="p"
											value={feature.description}
											onChange={(val) =>
												updateFeature(index, 'description', val)
											}
											placeholder={__('Feature description…', 'value-section')}
											allowedFormats={['core/bold', 'core/italic']}
										/>
										<Button
											variant="tertiary"
											isDestructive
											className="value-remove-feature"
											onClick={() => removeFeature(index)}
										>
											{__('✕ Remove', 'value-section')}
										</Button>
									</div>
								</div>
							))}

							<Button
								variant="primary"
								className="value-add-feature"
								onClick={addFeature}
							>
								{__('+ Add Feature', 'value-section')}
							</Button>
						</div>
					</div>
				</div>
			</div>
		</section>
	);
}