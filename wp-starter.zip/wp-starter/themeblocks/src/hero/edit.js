import {
	useBlockProps,
	RichText,
	MediaUpload,
	MediaUploadCheck,
} from '@wordpress/block-editor';
import { Button, Placeholder, TextControl } from '@wordpress/components';
import { __ } from '@wordpress/i18n';

export default function Edit({ attributes, setAttributes }) {
	const {
		titleMain,
		titleAccent,
		subtitle,
		btnPrimaryText,
		btnPrimaryUrl,
		btnSecondaryText,
		btnSecondaryUrl,
		stat1Number,
		stat1Label,
		stat2Number,
		stat2Label,
		stat3Number,
		stat3Label,
		imageUrl,
		imageAlt,
		imageId,
	} = attributes;

	const blockProps = useBlockProps({ className: 'hero' });

	return (
		<section {...blockProps}>
			<div className="hero-background"></div>
			<div className="container hero-container">
				<div className="hero-content">

					{/* Title */}
					<h1 className="hero-title">
						<RichText
							tagName="span"
							className="hero-title-main"
							value={titleMain}
							onChange={(val) => setAttributes({ titleMain: val })}
							placeholder={__('Main title…', 'tqb-hero')}
							allowedFormats={[]}
						/>
						<br />
						<RichText
							tagName="span"
							className="hero-title-accent"
							value={titleAccent}
							onChange={(val) => setAttributes({ titleAccent: val })}
							placeholder={__('Accent title…', 'tqb-hero')}
							allowedFormats={[]}
						/>
					</h1>

					{/* Subtitle */}
					<RichText
						tagName="p"
						className="hero-subtitle"
						value={subtitle}
						onChange={(val) => setAttributes({ subtitle: val })}
						placeholder={__('Subtitle text…', 'tqb-hero')}
						allowedFormats={['core/bold', 'core/italic']}
					/>

					{/* CTA Buttons */}
					<div className="hero-cta-group">
						<div className="btn-editable-wrap">
							<RichText
								tagName="span"
								className="btn btn-primary"
								value={btnPrimaryText}
								onChange={(val) => setAttributes({ btnPrimaryText: val })}
								placeholder={__('Primary button…', 'tqb-hero')}
								allowedFormats={[]}
							/>
							<div className="url-input-wrap">
								<TextControl
									label={__('Primary URL:', 'tqb-hero')}
									value={btnPrimaryUrl}
									onChange={(val) => setAttributes({ btnPrimaryUrl: val })}
									placeholder="https://"
									type="url"
								/>
							</div>
						</div>

						<div className="btn-editable-wrap">
							<RichText
								tagName="span"
								className="btn btn-secondary"
								value={btnSecondaryText}
								onChange={(val) => setAttributes({ btnSecondaryText: val })}
								placeholder={__('Secondary button…', 'tqb-hero')}
								allowedFormats={[]}
							/>
							<div className="url-input-wrap">
								<TextControl
									label={__('Secondary URL:', 'tqb-hero')}
									value={btnSecondaryUrl}
									onChange={(val) => setAttributes({ btnSecondaryUrl: val })}
									placeholder="https://"
									type="url"
								/>
							</div>
						</div>
					</div>

					{/* Stats */}
					<div className="hero-stats">
						{[
							{ num: stat1Number, label: stat1Label, setNum: (v) => setAttributes({ stat1Number: v }), setLabel: (v) => setAttributes({ stat1Label: v }) },
							{ num: stat2Number, label: stat2Label, setNum: (v) => setAttributes({ stat2Number: v }), setLabel: (v) => setAttributes({ stat2Label: v }) },
							{ num: stat3Number, label: stat3Label, setNum: (v) => setAttributes({ stat3Number: v }), setLabel: (v) => setAttributes({ stat3Label: v }) },
						].map((stat, i) => (
							<div className="stat-item" key={i}>
								<RichText
									tagName="div"
									className="stat-number"
									value={stat.num}
									onChange={stat.setNum}
									placeholder={__('0+', 'tqb-hero')}
									allowedFormats={[]}
								/>
								<RichText
									tagName="div"
									className="stat-label"
									value={stat.label}
									onChange={stat.setLabel}
									placeholder={__('Stat label…', 'tqb-hero')}
									allowedFormats={[]}
								/>
							</div>
						))}
					</div>
				</div>

				{/* Hero Visual / Image */}
				<div className="hero-visual">
					<MediaUploadCheck>
						<MediaUpload
							onSelect={(media) =>
								setAttributes({
									imageUrl: media.url,
									imageAlt: media.alt || imageAlt,
									imageId: media.id,
								})
							}
							allowedTypes={['image']}
							value={imageId}
							render={({ open }) => (
								<>
									{imageUrl ? (
										<div className="hero-image-wrap">
											<img
												src={imageUrl}
												alt={imageAlt}
												className="bearing-showcase"
											/>
											<div className="hero-image-actions">
												<Button
													onClick={open}
													variant="secondary"
													className="replace-image-btn"
												>
													{__('Replace Image', 'tqb-hero')}
												</Button>
												<Button
													onClick={() =>
														setAttributes({ imageUrl: '', imageId: 0, imageAlt: '' })
													}
													variant="secondary"
													isDestructive
												>
													{__('Remove', 'tqb-hero')}
												</Button>
											</div>
										</div>
									) : (
										<Placeholder
											icon="format-image"
											label={__('Hero Image', 'tqb-hero')}
											instructions={__('Upload or select an image for the hero section.', 'tqb-hero')}
										>
											<Button onClick={open} variant="primary">
												{__('Upload / Select Image', 'tqb-hero')}
											</Button>
										</Placeholder>
									)}
								</>
							)}
						/>
					</MediaUploadCheck>
				</div>
			</div>

			<div className="scroll-indicator">
				<div className="scroll-line"></div>
			</div>
		</section>
	);
}