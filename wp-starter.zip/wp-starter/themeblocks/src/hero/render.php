<?php
/**
 * Hero Block — Server-side render template.
 *
 * @var array    $attributes  Block attributes.
 * @var string   $content     Inner blocks content (unused).
 * @var WP_Block $block       Block instance.
 */

$title_main = isset($attributes['titleMain']) ? $attributes['titleMain'] : '';
$title_accent = isset($attributes['titleAccent']) ? $attributes['titleAccent'] : '';
$subtitle = isset($attributes['subtitle']) ? $attributes['subtitle'] : '';
$btn_primary = isset($attributes['btnPrimaryText']) ? $attributes['btnPrimaryText'] : '';
$btn_primary_url = isset($attributes['btnPrimaryUrl']) ? $attributes['btnPrimaryUrl'] : '#';
$btn_secondary = isset($attributes['btnSecondaryText']) ? $attributes['btnSecondaryText'] : '';
$btn_secondary_url = isset($attributes['btnSecondaryUrl']) ? $attributes['btnSecondaryUrl'] : '#';

$stat1_number = isset($attributes['stat1Number']) ? $attributes['stat1Number'] : '';
$stat1_label = isset($attributes['stat1Label']) ? $attributes['stat1Label'] : '';
$stat2_number = isset($attributes['stat2Number']) ? $attributes['stat2Number'] : '';
$stat2_label = isset($attributes['stat2Label']) ? $attributes['stat2Label'] : '';
$stat3_number = isset($attributes['stat3Number']) ? $attributes['stat3Number'] : '';
$stat3_label = isset($attributes['stat3Label']) ? $attributes['stat3Label'] : '';

$image_url = isset($attributes['imageUrl']) ? $attributes['imageUrl'] : '';
$image_alt = isset($attributes['imageAlt']) ? $attributes['imageAlt'] : '';
?>

<section class="hero">
	<div class="hero-background"></div>
	<div class="container hero-container">
		<div class="hero-content">

			<h1 class="hero-title">
				<?php echo wp_kses_post($title_main); ?><br>
				<span class="hero-title-accent"><?php echo wp_kses_post($title_accent); ?></span>
			</h1>

			<p class="hero-subtitle">
				<?php echo wp_kses_post($subtitle); ?>
			</p>

			<div class="hero-cta-group">
				<a href="<?php echo esc_url($btn_primary_url); ?>" class="btn btn-primary">
					<?php echo esc_html($btn_primary); ?>
					<svg class="btn-icon" width="20" height="20" viewBox="0 0 20 20" fill="none"
						xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
						<path d="M7.5 15L12.5 10L7.5 5" stroke="currentColor" stroke-width="2"
							stroke-linecap="round" stroke-linejoin="round" />
					</svg>
				</a>
				<a href="<?php echo esc_url($btn_secondary_url); ?>" class="btn btn-secondary">
					<?php echo esc_html($btn_secondary); ?>
				</a>
			</div>

			<div class="hero-stats">
				<?php
$stats = array(
		array('number' => $stat1_number, 'label' => $stat1_label),
		array('number' => $stat2_number, 'label' => $stat2_label),
		array('number' => $stat3_number, 'label' => $stat3_label),
);
foreach ($stats as $stat):
	if (empty($stat['number']) && empty($stat['label'])) {
		continue;
	}
?>
				<div class="stat-item">
					<div class="stat-number"><?php echo esc_html($stat['number']); ?></div>
					<div class="stat-label"><?php echo esc_html($stat['label']); ?></div>
				</div>
				<?php
endforeach; ?>
			</div>

		</div>

		<div class="hero-visual">
			<?php if (!empty($image_url)): ?>
				<img
					src="<?php echo esc_url($image_url); ?>"
					alt="<?php echo esc_attr($image_alt); ?>"
					class="bearing-showcase"
				>
			<?php
endif; ?>
		</div>

	</div>
	<div class="scroll-indicator">
		<div class="scroll-line"></div>
	</div>
</section>