<?php

get_header();
tqb_page_banner(); ?>

<section class="products-archive">
        <div class="container">
            <div class="archive-layout">
                <!-- Sidebar -->
                <?php get_sidebar('product'); ?>

                <!-- Main Content -->
                <main class="archive-main">
                    <!-- Filters & Sorting -->
                    <div class="archive-toolbar">
                        <div class="toolbar-left">
                            <p class="results-count">Showing <strong>1-12</strong> of <strong>24</strong> results</p>
                        </div>
                        <div class="toolbar-right">
                            <label for="sortBy" class="sort-label">Sort by:</label>
                            <select id="sortBy" class="sort-select">
                                <option value="default">Default</option>
                                <option value="name-asc">Name (A-Z)</option>
                                <option value="name-desc">Name (Z-A)</option>
                                <option value="newest">Newest First</option>
                            </select>
                        </div>
                    </div>

                    <!-- Product Grid -->
                    <div class="archive-grid">

                        <?php while (have_posts()) {
    the_post();
    get_template_part('template-parts/content', 'product');
}?>

                        

                        
                    </div>

                    <!-- Pagination -->
                    <div class="archive-pagination">
                        <button class="pagination-btn pagination-prev" disabled="">
                            <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M12.5 15L7.5 10L12.5 5" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path>
                            </svg>
                            Previous
                        </button>
                        <div class="pagination-numbers">
                            <button class="pagination-number active">1</button>
                            <button class="pagination-number">2</button>
                            <span class="pagination-dots">...</span>
                            <button class="pagination-number">5</button>
                        </div>
                        <button class="pagination-btn pagination-next">
                            Next
                            <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M7.5 15L12.5 10L7.5 5" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path>
                            </svg>
                        </button>
                    </div>
                </main>
            </div>
        </div>
    </section>

<?php get_footer(); ?>