<?php
/**
 * The template for displaying all pages.
 *
 * @package WP_Starter
 */

get_header();
?>

<main id="primary" class="site-main container" style="margin-top:500px">
	<?php
while (have_posts()):
	the_post();
	get_template_part('template-parts/content', 'page');

	if (comments_open() || get_comments_number()):
		comments_template();
	endif;
endwhile;
?>
</main>

<?php
get_sidebar();
get_footer();
