<?php
/**
 * The template for displaying 404 pages.
 *
 * @package WP_Starter
 */

get_header();
?>

<main id="primary" class="site-main container">
	<section class="error-404 not-found">
		<header class="page-header">
			<h1 class="page-title"><?php esc_html_e( 'Page not found', 'wp-starter' ); ?></h1>
		</header>

		<div class="page-content">
			<p><?php esc_html_e( 'It looks like nothing was found at this location. Try a search?', 'wp-starter' ); ?></p>
			<?php get_search_form(); ?>
		</div>
	</section>
</main>

<?php
get_footer();

