# Premium Wheel Hub Bearings - Industrial Manufacturing Website

A production-ready, conversion-focused website for a precision wheel hub bearing manufacturer. Built with modern web standards, elegant animations, and optimized for lead generation.

## Features

- **Hero-First Architecture**: Compelling hero section with animated bearing visualization
- **Trust & Credibility**: ISO certifications, testimonials, and industry partnerships
- **6 Core Features**: Detailed technical specifications with icon-based cards
- **4 Application Segments**: Targeted messaging for different industries
- **Contact Form**: Lead capture with custom engineering consultation
- **Fully Responsive**: Mobile, tablet, desktop, and large screen optimized
- **Elegant Animations**: Subtle fade-in, stagger, and parallax effects
- **Accessibility**: WCAG compliant with keyboard navigation and ARIA labels
- **Performance Optimized**: Clean code, debounced scroll events, CSS animations

## Technology Stack

- Pure HTML5/CSS3/JavaScript (no framework dependencies)
- Modern CSS Grid & Flexbox layouts
- Intersection Observer API for scroll animations
- CSS custom properties for theming
- Mobile-first responsive design

## Color Palette

- Primary: #1D4E89 (Industrial Steel Blue)
- Secondary: #333333 (Charcoal Grey)
- Background: #F5F5F5 (Soft Grey)
- Text: #333333 (High contrast)

## Typography

- Headings: Montserrat (sans-serif)
- Body: Inter (sans-serif)
- Optimized for technical readability

## Browser Support

- Chrome/Edge (latest)
- Firefox (latest)
- Safari (latest)
- Mobile browsers (iOS Safari, Chrome Mobile)

## Performance

- Optimized animations using CSS transforms
- Debounced scroll events
- RequestAnimationFrame for smooth parallax
- Lazy-loaded animations with Intersection Observer

## Setup

1. Open `index.html` in a web browser
2. No build process or dependencies required
3. All assets are self-contained

## Customization

- Colors: Edit CSS custom properties in `styles.css` (`:root` section)
- Content: Update HTML in `index.html`
- Animations: Modify keyframes and transitions in `styles.css`
- Form submission: Replace console.log in `script.js` with actual API endpoint

## File Structure

```
├── index.html          # Main HTML structure
├── styles.css          # All styles and animations
├── script.js           # Interactive functionality
└── README.md           # Documentation
```

## Sections

1. **Navigation**: Fixed header with smooth scroll
2. **Hero**: Full-screen with animated bearing showcase and stats
3. **Trust**: ISO certifications and client testimonials
4. **Features**: 6 detailed technical features with specs
5. **Value**: Engineering excellence with numbered benefits
6. **Applications**: 4 industry-specific use cases
7. **CTA/Contact**: Lead generation form with consultation request
8. **Footer**: Company info, links, and legal

## Accessibility

- Semantic HTML5 elements
- ARIA labels where needed
- Keyboard navigable
- Focus states for all interactive elements
- High contrast text for readability
- Screen reader announcements for dynamic content

## License

Proprietary - Production ready code for client use

## Credits

Design: Senior UI/UX designer standards
Development: Modern web best practices
Inspired by: Rolls-Royce, Bosch, Caterpillar industrial design
