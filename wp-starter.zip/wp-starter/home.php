<?php get_header(  ); ?>




this is the blog page




<?php get_footer(  ); ?>