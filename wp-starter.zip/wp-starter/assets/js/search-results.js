// Search Results Page JavaScript

// Sample data for demonstration
const searchData = [
    {
        type: 'product',
        title: 'Premium Quality Product A',
        url: 'product-detail.html?id=1',
        description: 'High-quality manufacturing product designed for superior performance and reliability in industrial applications.',
        date: '2026-01-03',
        category: 'Products'
    },
    {
        type: 'product',
        title: 'Advanced Manufacturing Solution B',
        url: 'product-detail.html?id=2',
        description: 'Cutting-edge technology product with innovative features for modern manufacturing needs.',
        date: '2026-01-02',
        category: 'Products'
    },
    {
        type: 'news',
        title: 'Company Achieves New Quality Certification',
        url: 'news-single.html?id=1',
        description: 'We are proud to announce our latest ISO certification, demonstrating our commitment to quality excellence.',
        date: '2025-12-15',
        category: 'News'
    },
    {
        type: 'news',
        title: 'Innovation in Manufacturing Technology',
        url: 'news-single.html?id=2',
        description: 'Our latest technology breakthrough in sustainable manufacturing processes sets new industry standards.',
        date: '2025-12-10',
        category: 'News'
    },
    {
        type: 'page',
        title: 'Quality Control Standards',
        url: 'quality-control.html',
        description: 'Learn about our comprehensive quality control processes, certifications, and commitment to excellence.',
        date: '2026-01-01',
        category: 'Pages'
    },
    {
        type: 'page',
        title: 'About Our Company',
        url: 'about.html',
        description: 'Discover our history, mission, values, and the team behind our success in the manufacturing industry.',
        date: '2026-01-01',
        category: 'Pages'
    },
    {
        type: 'page',
        title: 'Contact Us',
        url: 'contact.html',
        description: 'Get in touch with our team. We are here to answer your questions and discuss your needs.',
        date: '2026-01-01',
        category: 'Pages'
    },
    {
        type: 'product',
        title: 'Sustainable Manufacturing Equipment',
        url: 'product-detail.html?id=3',
        description: 'Eco-friendly manufacturing equipment designed with sustainability and efficiency in mind.',
        date: '2025-12-20',
        category: 'Products'
    }
];

let currentFilter = 'all';
let currentPage = 1;
const resultsPerPage = 5;
let filteredResults = [];

// Get search query from URL
function getSearchQuery() {
    const urlParams = new URLSearchParams(window.location.search);
    return urlParams.get('q') || '';
}

// Perform search
function performSearch(query, filter = 'all') {
    if (!query) return [];
    
    const searchTerm = query.toLowerCase();
    
    return searchData.filter(item => {
        // Filter by type
        if (filter !== 'all' && item.type !== filter) {
            return false;
        }
        
        // Search in title, description, and category
        return item.title.toLowerCase().includes(searchTerm) ||
               item.description.toLowerCase().includes(searchTerm) ||
               item.category.toLowerCase().includes(searchTerm);
    });
}

// Highlight search terms
function highlightText(text, query) {
    if (!query) return text;
    
    const regex = new RegExp(`(${query})`, 'gi');
    return text.replace(regex, '<span class="highlight">$1</span>');
}

// Display results
function displayResults(results, query) {
    const container = document.getElementById('resultsContainer');
    const noResults = document.getElementById('noResults');
    const pagination = document.getElementById('pagination');
    
    if (results.length === 0) {
        container.style.display = 'none';
        noResults.style.display = 'block';
        pagination.style.display = 'none';
        document.getElementById('noResultsQuery').textContent = query;
        return;
    }
    
    container.style.display = 'flex';
    noResults.style.display = 'none';
    
    // Calculate pagination
    const totalPages = Math.ceil(results.length / resultsPerPage);
    const startIndex = (currentPage - 1) * resultsPerPage;
    const endIndex = startIndex + resultsPerPage;
    const pageResults = results.slice(startIndex, endIndex);
    
    // Generate HTML for results
    container.innerHTML = pageResults.map(result => `
        <div class="result-card" data-type="${result.type}">
            <div class="result-header">
                <span class="result-type type-${result.type}">${result.type}</span>
            </div>
            <div class="result-content">
                <h3 class="result-title">
                    <a href="${result.url}">${highlightText(result.title, query)}</a>
                </h3>
                <span class="result-url">${window.location.origin}/${result.url}</span>
                <p class="result-description">${highlightText(result.description, query)}</p>
                <div class="result-meta">
                    <span>📅 ${formatDate(result.date)}</span>
                    <span>📁 ${result.category}</span>
                </div>
            </div>
        </div>
    `).join('');
    
    // Display pagination if needed
    if (totalPages > 1) {
        pagination.style.display = 'flex';
        displayPagination(totalPages);
    } else {
        pagination.style.display = 'none';
    }
}

// Format date
function formatDate(dateString) {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' });
}

// Display pagination
function displayPagination(totalPages) {
    const pageNumbers = document.getElementById('pageNumbers');
    const prevBtn = document.getElementById('prevBtn');
    const nextBtn = document.getElementById('nextBtn');
    
    // Generate page numbers
    let pagesHTML = '';
    for (let i = 1; i <= totalPages; i++) {
        if (i === 1 || i === totalPages || (i >= currentPage - 1 && i <= currentPage + 1)) {
            pagesHTML += `<div class="page-number ${i === currentPage ? 'active' : ''}" data-page="${i}">${i}</div>`;
        } else if (i === currentPage - 2 || i === currentPage + 2) {
            pagesHTML += `<span style="padding: 0 0.5rem;">...</span>`;
        }
    }
    pageNumbers.innerHTML = pagesHTML;
    
    // Update button states
    prevBtn.disabled = currentPage === 1;
    nextBtn.disabled = currentPage === totalPages;
    
    // Add click handlers to page numbers
    document.querySelectorAll('.page-number').forEach(btn => {
        btn.addEventListener('click', () => {
            currentPage = parseInt(btn.dataset.page);
            displayResults(filteredResults, getSearchQuery());
        });
    });
}

// Update results count
function updateResultsCount(count, query) {
    document.getElementById('resultsCount').textContent = count;
    document.getElementById('searchQuery').textContent = query;
}

// Initialize page
function init() {
    const query = getSearchQuery();
    const searchInput = document.getElementById('searchInput');
    
    if (query) {
        searchInput.value = query;
        filteredResults = performSearch(query, currentFilter);
        updateResultsCount(filteredResults.length, query);
        displayResults(filteredResults, query);
    } else {
        // Show all results by default when no search query
        searchInput.value = '';
        filteredResults = searchData; // Show all data
        document.getElementById('searchQuery').textContent = 'all results';
        updateResultsCount(filteredResults.length, 'all results');
        displayResults(filteredResults, '');
    }
}

// Event listeners
document.addEventListener('DOMContentLoaded', () => {
    init();
    
    // Search form submission
    document.getElementById('searchForm').addEventListener('submit', (e) => {
        e.preventDefault();
        const query = document.getElementById('searchInput').value.trim();
        if (query) {
            window.location.href = `search-results.html?q=${encodeURIComponent(query)}`;
        }
    });
    
    // Filter buttons
    document.querySelectorAll('.filter-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            
            currentFilter = btn.dataset.filter;
            currentPage = 1;
            const query = getSearchQuery();
            filteredResults = performSearch(query, currentFilter);
            updateResultsCount(filteredResults.length, query);
            displayResults(filteredResults, query);
        });
    });
    
    // Pagination buttons
    document.getElementById('prevBtn').addEventListener('click', () => {
        if (currentPage > 1) {
            currentPage--;
            displayResults(filteredResults, getSearchQuery());
        }
    });
    
    document.getElementById('nextBtn').addEventListener('click', () => {
        const totalPages = Math.ceil(filteredResults.length / resultsPerPage);
        if (currentPage < totalPages) {
            currentPage++;
            displayResults(filteredResults, getSearchQuery());
        }
    });
    
    // Popular tags
    document.querySelectorAll('.tag').forEach(tag => {
        tag.addEventListener('click', (e) => {
            e.preventDefault();
            const searchTerm = tag.dataset.search;
            window.location.href = `search-results.html?q=${encodeURIComponent(searchTerm)}`;
        });
    });
});
