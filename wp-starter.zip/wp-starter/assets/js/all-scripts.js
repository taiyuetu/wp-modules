/* ===================================
   COMBINED SCRIPTS - ALL JS FILES
   This file combines all individual JavaScript files
   You can use this single file instead of loading multiple JS files
   =================================== */

// Load all JavaScript files in order
(function() {
    'use strict';
    
    // Array of script files to load
    const scripts = [
        'script.js',           // Main navigation and base functionality
        'gallery.js',          // Gallery page functionality
        'news.js',             // News page functionality
        'product-detail.js',   // Product detail page functionality
        'search-results.js'    // Search results page functionality
    ];
    
    // Function to load scripts dynamically
    function loadScript(src) {
        return new Promise((resolve, reject) => {
            const script = document.createElement('script');
            script.src = src;
            script.onload = resolve;
            script.onerror = reject;
            document.body.appendChild(script);
        });
    }
    
    // Load all scripts sequentially
    async function loadAllScripts() {
        for (const scriptSrc of scripts) {
            try {
                await loadScript(scriptSrc);
                console.log(`Loaded: ${scriptSrc}`);
            } catch (error) {
                console.warn(`Failed to load ${scriptSrc}:`, error);
            }
        }
    }
    
    // Start loading when DOM is ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', loadAllScripts);
    } else {
        loadAllScripts();
    }
})();

/* 
Usage: Replace all individual script tags in your HTML with:
<script src="all-scripts.js"></script>

Note: This dynamically loads all individual files, keeping them intact.
If you prefer direct inclusion, you can manually copy the contents of each
JS file below instead of using dynamic loading.
*/
